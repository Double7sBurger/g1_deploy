"""Select a motion checkpoint from eight seeds using identical clean/DR trials."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil


def rank(candidate):
    """Completion precedes error: early failure must never look like good tracking."""
    suites = candidate["suites"]
    clean, robust = suites["clean"], suites["robust"]
    return (
        min(clean["full_clip_success_rate"], robust["full_clip_success_rate"]),
        sum(s["full_clip_success_rate"] for s in suites.values()) / 2,
        sum(s["mean_fraction_survived"] for s in suites.values()) / 2,
        sum(s["phase_suffix_success_rate"] for s in suites.values()) / 2,
        -sum(s.get("foot_slip_mean_speed_m_s", 0.0) for s in suites.values()) / 2,
        -sum(s["body_position_error_m"] for s in suites.values()) / 2,
        -sum(s["joint_limit_violation_fraction"] for s in suites.values()) / 2,
        -sum(s["foot_orientation_error_deg"] for s in suites.values()) / 2,
        -candidate["seed"],
        candidate["iteration"],
    )


def collect(root):
    root = Path(root)
    assert (root / "COMPLETE.txt").is_file(), f"Incomplete experiment: {root}"
    experiment = json.loads((root / "experiment.json").read_text())
    assert experiment["dr"]
    result = []
    for iteration in (20000, 25000, 29999):
        checkpoint, = root.rglob(f"model_{iteration}.pt")
        digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        suites = {}
        for suite in ("clean", "robust"):
            reports = []
            for eval_seed in (2026, 2027):
                report = json.loads((root / "evaluations" / str(iteration) / suite / str(eval_seed) / "evaluation.json").read_text())
                assert report["protocol"] == experiment.get("evaluation_protocol", "fixed-start-v2-fresh-observations")
                assert report["friction_range"] == ([1.0, 1.0] if suite == "clean" else experiment.get("friction_range", [0.4, 1.2]))
                assert report["ground_friction"] == (1.0 if suite == "clean" else 0.0)
                assert report["suite"] == suite and report["seed"] == eval_seed
                assert report["checkpoint_sha256"] == digest
                assert report["motion_sha256"] == experiment["motion_sha256"]
                assert report.get("sysid_sha256") == experiment.get("sysid_sha256")
                assert len(report["success"]) == 64
                reports.append(report)
            suites[suite] = {
                key: sum(r[key] for r in reports) / len(reports)
                for key in ("full_clip_success_rate", "phase_suffix_success_rate", "mean_fraction_survived", "full_clip_survival_seconds")
            }
            suites[suite].update(
                body_position_error_m=sum(r["mean_errors_while_alive"]["error_body_pos"] for r in reports) / 2,
                joint_limit_violation_fraction=sum(r["quality_measurement"]["full_clip"]["position_violation_physics_frame_fraction_gt_1deg"] for r in reports) / 2,
                foot_orientation_error_deg=sum(sum(r["quality_measurement"]["full_clip"]["foot_orientation_mean_deg"]) / 2 for r in reports) / 2,
                max_joint_limit_excess_deg=max(max(r["quality_measurement"]["full_clip"]["joint_peak_position_limit_excess_deg"]) for r in reports),
                actual_push_count=sum(sum(r.get("push_counts", r["push_applied"])) for r in reports),
            )
            if "friction_range" in experiment:
                suites[suite]["foot_slip_mean_speed_m_s"] = sum(
                    r["foot_slip"]["full_clip"]["mean_speed_m_s"] for r in reports
                ) / 2
        result.append({"motion": experiment["arm"], "seed": experiment["seed"], "iteration": iteration,
                       "motion_sha256": experiment["motion_sha256"], "checkpoint_sha256": digest,
                       "checkpoint": str(checkpoint), "root": str(root), "suites": suites})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", nargs=8, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    candidates = []
    settings = []
    for path in args.inputs:
        complete, = path.rglob("COMPLETE.txt")
        experiment = json.loads((complete.parent / "experiment.json").read_text())
        settings.append((experiment.get("friction_range"), experiment.get("foot_slip_weight", 0.0),
                         experiment.get("dr_ablation"), experiment.get("evaluation_protocol"),
                         experiment.get("sysid_sha256"), experiment.get("sysid_friction")))
        candidates.extend(collect(complete.parent))
    assert all(setting == settings[0] for setting in settings)
    assert {c["seed"] for c in candidates} == set(range(42, 50))
    assert len({c["motion_sha256"] for c in candidates}) == 1
    assert len({c["motion"] for c in candidates}) == 1
    ordered = sorted(candidates, key=rank, reverse=True)
    best = ordered[0]
    distinct = []
    for candidate in ordered:
        if candidate['seed'] not in {item['seed'] for item in distinct}:
            distinct.append(candidate)
    best_two = distinct[:2]
    assert len(best_two) == 2 and len(candidates) == 24
    args.output.mkdir(parents=True, exist_ok=True)
    selection = {
        "ranking": "worst-suite full completion, mean full completion, survival fraction, suffix completion, foot slip speed when measured, body position error, limit violation fraction, foot rotation error; ties lower seed then later checkpoint",
        "all_eight_seeds_complete": True,
        "best": best, "best_two": best_two, "best_per_seed": distinct, "candidates": ordered,
        "clean_full_completion_at_least_95pct": best["suites"]["clean"]["full_clip_success_rate"] >= 0.95,
        "robust_full_completion_at_least_95pct": best["suites"]["robust"]["full_clip_success_rate"] >= 0.95,
        "hardware_validated": False,
        "friction_range": settings[0][0],
        "foot_slip_weight": settings[0][1],
        "dr_ablation": settings[0][2],
        "evaluation_protocol": settings[0][3],
        "sysid_sha256": settings[0][4], "sysid_friction": settings[0][5],
    }
    (args.output / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    for place, choice in enumerate(best_two, 1):
        folder = args.output / f"best_{place}"
        folder.mkdir(exist_ok=True)
        checkpoint = Path(choice["checkpoint"])
        shutil.copy2(checkpoint, folder / checkpoint.name)
        root = Path(choice["root"])
        for name in ("experiment.json", "source_manifest.json", "training_summary.json", "reference.npz", "reference.json"):
            shutil.copy2(root / name, folder / name)
        if settings[0][4]:
            shutil.copy2(root / "sysid_parameters.json", folder / "sysid_parameters.json")
        shutil.copytree(checkpoint.parent / "params", folder / "params", dirs_exist_ok=True)
        shutil.copytree(root / "evaluations" / str(choice["iteration"]), folder / "evaluations", dirs_exist_ok=True)
        assert hashlib.sha256((folder / checkpoint.name).read_bytes()).hexdigest() == choice["checkpoint_sha256"]
    (args.output / "SELECTION_COMPLETE.txt").write_text("Eight seeds complete; two distinct seed winners packaged.\n")
    print(json.dumps(selection), flush=True)


if __name__ == "__main__":
    main()
