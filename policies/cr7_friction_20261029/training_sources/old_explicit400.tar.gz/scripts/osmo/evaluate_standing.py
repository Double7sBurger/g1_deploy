"""Evaluate a stationary mimic actor for 60 s with repeated, reproducible pushes."""

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
import warp as wp
from rsl_rl.runners import OnPolicyRunner
from isaaclab.app import launch_simulation
from isaaclab.utils.math import quat_error_magnitude
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper, handle_deprecated_rsl_rl_cfg
from motion_tracking.tasks.motion_tracking.agents.rsl_rl_ppo_cfg import G1MotionTrackingPPORunnerCfg
from motion_tracking.tasks.motion_tracking.motion_standing_env_cfg import MotionStandingEnvCfg

wp.config.enable_backward = False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--suite', choices=('clean', 'robust'), default='robust')
    parser.add_argument('--seed', type=int, default=2026)
    parser.add_argument('--duration', type=float, default=60.0)
    parser.add_argument('--num_envs', type=int, default=64)
    args = parser.parse_args()
    if not np.isfinite(args.duration) or args.duration <= 0 or args.num_envs <= 0:
        parser.error('Duration and number of environments must be positive')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cfg = MotionStandingEnvCfg()
    cfg.scene.num_envs = args.num_envs
    cfg.seed = args.seed
    cfg.episode_length_s = args.duration + 0.1
    cfg.events.push_robot = None  # Apply identical scheduled disturbances to every candidate.
    cfg.observations.policy.enable_corruption = args.suite == 'robust'
    if args.suite == 'clean':
        cfg.events.add_base_mass = None
        cfg.events.physics_material.params['static_friction_range'] = (1.0, 1.0)
        cfg.events.physics_material.params['dynamic_friction_range'] = (1.0, 1.0)
        cfg.commands.motion.pose_range = {}
        cfg.commands.motion.velocity_range = {}
        cfg.commands.motion.joint_position_range = (0.0, 0.0)
    agent = handle_deprecated_rsl_rl_cfg(G1MotionTrackingPPORunnerCfg(), importlib.metadata.version('rsl-rl-lib'))
    with launch_simulation(cfg, {'visualizer': None, 'visualizer_explicit': True}):
        env = gym.make('Motion-Standing-G1-v0', cfg=cfg).unwrapped
        assert 'Newton' in env.sim.physics_manager.__name__ and not env._physics_handles_decimation
        vec = RslRlVecEnvWrapper(env, clip_actions=agent.clip_actions)
        runner = OnPolicyRunner(vec, agent.to_dict(), log_dir=None, device=env.device)
        runner.load(str(args.checkpoint))
        policy = runner.get_inference_policy(device=env.device)
        env.reset(seed=args.seed)
        command = env.command_manager.get_term('motion')
        robot = command.robot
        env.sim.forward()
        env.scene.update(env.physics_dt)
        command._update_command()
        env.obs_buf = env.observation_manager.compute()
        obs = vec.get_observations()
        assert obs['policy'].shape[-1] == 154 and obs['critic'].shape[-1] == 286
        steps = int(round(args.duration / env.step_dt))
        alive = torch.ones(env.num_envs, dtype=torch.bool, device=env.device)
        survived = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
        pushes = torch.zeros_like(survived)
        sums = {k: torch.zeros(env.num_envs, device=env.device) for k in ('body_pos', 'joint_rms', 'joint_speed_rms')}
        peak_tilt = torch.zeros(env.num_envs, device=env.device)
        peak_drift = torch.zeros_like(peak_tilt)
        limit_bad = torch.zeros_like(peak_tilt)
        limit_peak = torch.zeros_like(peak_tilt)
        physics_samples = torch.zeros_like(survived)
        limits = robot.data.joint_pos_limits.torch.clone()
        initial_xy = robot.data.root_pos_w.torch[:, :2].clone()
        generator = torch.Generator(device=env.device).manual_seed(args.seed + 10000)
        push_log, trajectory, positions, rotations, joints = [], [], [], [], []
        original_update = env.scene.update

        def update_and_measure(*a, **kw):
            original_update(*a, **kw)
            q = robot.data.joint_pos.torch
            over = torch.maximum(limits[..., 0] - q, q - limits[..., 1]).clamp_min(0).amax(-1)
            limit_bad.add_((over > np.deg2rad(1)) & alive)
            limit_peak.copy_(torch.maximum(limit_peak, over * alive))
            physics_samples.add_(alive)

        env.scene.update = update_and_measure
        with torch.inference_mode():
            for step in range(steps):
                if not alive.any():
                    break
                if args.suite == 'robust' and step > 0 and step % round(5 / env.step_dt) == 0:
                    ids = alive.nonzero().flatten()
                    delta = (torch.rand((env.num_envs, 6), generator=generator, device=env.device) * 2 - 1)
                    delta *= torch.tensor([0.5, 0.5, 0, 0.3, 0.3, 0.3], device=env.device)
                    robot.write_root_velocity_to_sim_index(root_velocity=robot.data.root_vel_w.torch[ids] + delta[ids], env_ids=ids)
                    pushes[ids] += 1
                    push_log.append(dict(time_s=step * env.step_dt, env_ids=ids.tolist(), delta_velocity=delta[ids].tolist()))
                    env.obs_buf = env.observation_manager.compute()
                    obs = vec.get_observations()
                assert not command.time_steps.any()
                command._update_metrics()
                sums['body_pos'].add_(command.metrics['error_body_pos'] * alive)
                sums['joint_rms'].add_((command.joint_pos - command.robot_joint_pos).square().mean(-1).sqrt() * alive)
                sums['joint_speed_rms'].add_(command.robot_joint_vel.square().mean(-1).sqrt() * alive)
                tilt = quat_error_magnitude(command.anchor_quat_w, command.robot_anchor_quat_w)
                drift = (robot.data.root_pos_w.torch[:, :2] - initial_xy).norm(dim=-1)
                peak_tilt.copy_(torch.maximum(peak_tilt, tilt * alive))
                peak_drift.copy_(torch.maximum(peak_drift, drift * alive))
                if alive[0]:
                    positions.append((robot.data.body_pos_w.torch[0] - env.scene.env_origins[0]).cpu().numpy().copy())
                    rotations.append(robot.data.body_quat_w.torch[0][:, [3, 0, 1, 2]].cpu().numpy().copy())
                    joints.append(robot.data.joint_pos.torch[0].cpu().numpy().copy())
                    trajectory.append(torch.stack([command.robot_body_pos_w[0], command.body_pos_relative_w[0]]).cpu().numpy())
                actions = policy(obs)
                assert torch.isfinite(actions).all()
                obs, _, done, _ = vec.step(actions)
                survived += alive.long()
                alive &= ~done.bool()
        env.scene.update = original_update
        count = survived.sum().clamp_min(1)
        report = dict(protocol='static-pose-60s-v1', suite=args.suite, seed=args.seed,
                      friction_range=cfg.events.physics_material.params['static_friction_range'],
                      ground_friction=cfg.scene.terrain.physics_material.static_friction,
                      duration_s=steps * env.step_dt, num_envs=env.num_envs, physics=env.sim.physics_manager.__name__,
                      checkpoint=str(args.checkpoint), checkpoint_sha256=hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
                      motion_file=cfg.commands.motion.motion_file,
                      motion_sha256=hashlib.sha256(Path(cfg.commands.motion.motion_file).read_bytes()).hexdigest(),
                      fixed_frame_index=0, success=alive.tolist(), success_rate=alive.float().mean().item(),
                      survived_seconds=(survived * env.step_dt).tolist(), mean_fraction_survived=(survived / steps).mean().item(),
                      mean_errors_while_alive={k: (v.sum() / count).item() for k, v in sums.items()},
                      max_orientation_error_deg=torch.rad2deg(peak_tilt).tolist(), max_xy_drift_m=peak_drift.tolist(),
                      push_counts=pushes.tolist(), push_events=push_log,
                      joint_limit_violation_fraction=(limit_bad.sum() / physics_samples.sum().clamp_min(1)).item(),
                      max_joint_limit_excess_deg=torch.rad2deg(limit_peak).max().item(),
                      torso_masses_kg=robot.data.body_mass.torch[:, robot.body_names.index('torso_link')].tolist(),
                      hardware_validated=False)
        args.output.write_text(json.dumps(report, indent=2) + '\n')
        np.savez_compressed(args.output.with_suffix('.npz'), bodies=np.asarray(trajectory), body_names=command.cfg.body_names, fps=50)
        mesh = args.output.with_name('policy_poses.npz')
        np.savez_compressed(mesh, body_pos_w=np.asarray(positions), body_quat_w=np.asarray(rotations), joint_pos=np.asarray(joints), fps=50)
        mesh.with_suffix('.json').write_text(json.dumps(dict(body_names=robot.body_names, joint_names=robot.joint_names,
            quaternion_order='wxyz', sha256=hashlib.sha256(mesh.read_bytes()).hexdigest(), success=bool(alive[0]),
            checkpoint=str(args.checkpoint), env_index=0, provenance='Actual Newton stationary mimic rollout'), indent=2) + '\n')
        print('STANDING_EVALUATION', json.dumps({k: report[k] for k in ('suite','seed','success_rate','mean_errors_while_alive','push_counts')}), flush=True)
        env.close()


if __name__ == '__main__':
    main()
