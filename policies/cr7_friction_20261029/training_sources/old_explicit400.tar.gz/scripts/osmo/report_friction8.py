"""Package both seed winners for each SysID/friction experiment."""

import argparse
import hashlib
import html
import json
from pathlib import Path
import shutil


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, nargs=4, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    groups, packages, rows = {}, {}, []
    for source in args.inputs:
        path, = source.rglob("selection.json")
        selected = json.loads(path.read_text())
        assert selected["all_eight_seeds_complete"]
        assert len(selected["candidates"]) == 24
        winners = selected["best_two"]
        assert len(winners) == 2 and winners[0]["seed"] != winners[1]["seed"]
        name = winners[0]["motion"]
        assert name not in groups
        groups[name] = selected
        packages[name] = []
        for place, winner in enumerate(winners, 1):
            root = path.parent / f"best_{place}"
            destination = args.output / "best" / name / f"rank_{place}"
            shutil.copytree(root, destination, dirs_exist_ok=True)
            checkpoint = destination / Path(winner["checkpoint"]).name
            assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == winner["checkpoint_sha256"]
            assert hashlib.sha256((destination / "sysid_parameters.json").read_bytes()).hexdigest() == selected["sysid_sha256"]
            record = dict(winner, packaged_checkpoint=str(checkpoint.relative_to(args.output)))
            packages[name].append(record)
            clean, robust = (winner["suites"][suite] for suite in ("clean", "robust"))
            cells = [name, str(place), str(winner["seed"]), str(winner["iteration"]),
                     f'{clean["full_clip_success_rate"]:.1%} / {robust["full_clip_success_rate"]:.1%}',
                     f'{100*clean["body_position_error_m"]:.2f} / {100*robust["body_position_error_m"]:.2f}',
                     f'{clean["foot_slip_mean_speed_m_s"]:.4f} / {robust["foot_slip_mean_speed_m_s"]:.4f}']
            rows.append("<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in cells) +
                        f'<td><a href="{record["packaged_checkpoint"]}">checkpoint</a></td></tr>')
    assert set(groups) == {f"{motion}-{variant}" for motion in ("walk", "cr7") for variant in ("shared", "ground")}
    hashes = {group["sysid_sha256"] for group in groups.values()}
    assert len(hashes) == 1
    report = dict(training_runs=32, evaluated_checkpoints=96, seeds=list(range(42, 50)),
                  protocol="shared-dr-v1", sysid_sha256=hashes.pop(), groups=groups,
                  best_two_per_group=packages, hardware_validated=False,
                  selection="Two distinct training seeds per motion/experiment; each seed contributes its best tested checkpoint.",
                  test_conditions="Common clean and robust suites, eval seeds 2026/2027; 64 full clips and 64 suffixes per suite. Both enforce 500 deg/s. Robust adds foot friction, mass/COM/encoder/noise and 1–3s six-axis pushes.",
                  limitations="Simulation only. Small error on a short failed rollout does not imply complete motion. Best available is not a passing qualification.")
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    page = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>SysID 摩擦对照</title>
<style>body{font:16px system-ui;max-width:1400px;margin:40px auto;padding:20px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd4df;padding:10px;text-align:left}th{background:#eef3fa}p{line-height:1.7}</style>
<h1>SysID：共享摩擦与地面独立摩擦</h1>
<p>walk、CR7；每组 8 seeds（42–49）；每次 30,000 更新、4096 环境。两组使用相同 26 关节 SysID、无灵巧手官方 G1 29DOF、400 Hz 物理 / 50 Hz policy。共享组随机机器人整体摩擦；地面组机器人材质固定，仅地面摩擦每环境独立采样 0.5–1.5。</p>
<p>每组保留来自不同训练 seeds 的最佳两个候选。表中依次为普通 / 扰动评估。所有候选使用同一测试条件，含 500°/s 终止；优先比较完整动作完成率，再比较脚滑、跟踪和限位。未做真机验证。</p>
<table><tr><th>动作 / 实验</th><th>排名</th><th>seed</th><th>更新次数</th><th>完整成功率</th><th>身体误差 cm</th><th>接触脚滑 m/s</th><th>模型</th></tr>'''
    page += "".join(rows) + '</table><p><a href="report.json">全部 96 候选、每个 seed 的指标与校验和</a></p></html>'
    (args.output / "report.html").write_text(page)
    (args.output / "REPORT_COMPLETE.txt").write_text("32 trainings, 96 candidates, 8 selected checkpoints.\n")
    print("REPORT_COMPLETE", json.dumps({name: [(c["seed"], c["iteration"]) for c in values]
                                         for name, values in packages.items()}), flush=True)


if __name__ == "__main__":
    main()
