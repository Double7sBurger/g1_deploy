"""Summarize three-seed tracking ablations and package the best policy per motion."""

import argparse
import hashlib
import html
import json
from pathlib import Path
import shutil
import statistics

from select_dr import rank


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", nargs=6, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    selections = []
    folders = {}
    rows = []
    for root in args.inputs:
        path, = root.rglob("selection.json")
        selection = json.loads(path.read_text())
        assert selection["all_three_seeds_complete"]
        assert selection["evaluation_protocol"] == "shared-dr-v1"
        assert selection["friction_range"] == [0.5, 1.5]
        assert selection["foot_slip_weight"] == 0.0
        candidates = selection["candidates"]
        assert {(c["seed"], c["iteration"]) for c in candidates} == {
            (s, i) for s in (42, 43, 44) for i in (20000, 25000, 29999)
        }
        best = selection["best"]
        label = best["motion"]
        folders[label] = path.parent / "best"
        final = [c for c in candidates if c["iteration"] == 29999]
        summary = {}
        for suite in ("clean", "robust"):
            summary[suite] = {}
            for metric in ("full_clip_success_rate", "body_position_error_m", "foot_slip_mean_speed_m_s",
                           "joint_limit_violation_fraction", "foot_orientation_error_deg"):
                values = [c["suites"][suite][metric] for c in final]
                summary[suite][metric] = {"mean": statistics.mean(values), "std": statistics.stdev(values)}
        selections.append({"label": label, "dr_ablation": selection["dr_ablation"], "best": best,
                           "final_checkpoint_three_seed_statistics": summary, "candidates": candidates})
        clean, robust = best["suites"]["clean"], best["suites"]["robust"]
        rows.append([label, str(best["seed"]), str(best["iteration"]),
                     f'{clean["full_clip_success_rate"]:.1%} / {robust["full_clip_success_rate"]:.1%}',
                     f'{clean["body_position_error_m"] * 100:.2f} / {robust["body_position_error_m"] * 100:.2f}',
                     f'{clean["foot_slip_mean_speed_m_s"]:.4f} / {robust["foot_slip_mean_speed_m_s"]:.4f}',
                     f'{robust["joint_limit_violation_fraction"]:.2%}'])
    assert {s["label"] for s in selections} == {
        f"{motion}-{arm}" for motion in ("walk", "cr7") for arm in ("shared", "full", "guard")
    }
    winners = {}
    for motion in ("walk", "cr7"):
        candidates = [s["best"] for s in selections if s["label"].startswith(motion + "-")]
        assert len({c["motion_sha256"] for c in candidates}) == 1
        best = max(candidates, key=rank)
        source = folders[best["motion"]]
        target = args.output / "best" / motion
        shutil.copytree(source, target, dirs_exist_ok=True)
        checkpoint = target / f'model_{best["iteration"]}.pt'
        assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == best["checkpoint_sha256"]
        assert hashlib.sha256((target / "reference.npz").read_bytes()).hexdigest() == best["motion_sha256"]
        winners[motion] = dict(best, packaged_checkpoint=str(checkpoint.relative_to(args.output)))
    report = {
        "protocol": "shared-dr-v1", "training_runs": 18, "evaluated_checkpoints": 54,
        "selection": "Completion/survival first, then loaded-foot slip speed, tracking error and joint-limit metrics.",
        "test_conditions": "Identical clean and robust tests for every arm; seeds 2026/2027, 64 full clips plus 64 suffixes per suite. Robust: shared foot friction 0.5-1.5, torso mass/COM, encoder bias, observation/reset noise, six-axis pushes every 1-3 s. Both suites enforce 500 deg/s angular termination.",
        "baseline": "Training baseline: latest Newton official G1 29DOF, friction 0.5-1.5, action-rate -0.01, no foot-slip reward. Other pending experiments are not included as causal controls in this report.",
        "limitations": "Simulation evaluation only. Contact-centroid slip excludes torsional slip. Best available checkpoint does not imply all trials passed or hardware validation.",
        "groups": selections, "best_per_motion": winners,
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    columns = ["组别", "最佳 seed", "iteration", "完成率 clean / robust", "跟踪误差 cm clean / robust",
               "接触脚滑 m/s clean / robust", "robust 限位超出帧比例"]
    table = "<tr>" + "".join(f"<th>{html.escape(c)}</th>" for c in columns) + "</tr>"
    table += "".join("<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in row) + "</tr>" for row in rows)
    links = "".join(f'<li>{motion}: {html.escape(w["motion"])} / seed {w["seed"]} / '
                    f'iteration {w["iteration"]} — <a href="{w["packaged_checkpoint"]}">checkpoint</a></li>'
                    for motion, w in winners.items())
    variance_rows = []
    for group in selections:
        stats = group["final_checkpoint_three_seed_statistics"]["robust"]
        values = [group["label"]]
        for key, scale in (("full_clip_success_rate", 100), ("body_position_error_m", 100),
                           ("foot_slip_mean_speed_m_s", 1)):
            values.append(f'{stats[key]["mean"] * scale:.4f} ± {stats[key]["std"] * scale:.4f}')
        variance_rows.append("<tr>" + "".join(f"<td>{html.escape(v)}</td>" for v in values) + "</tr>")
    style = "body{font:16px system-ui;max-width:1300px;margin:40px auto;padding:20px;color:#18202c}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd4df;padding:10px;text-align:left}th{background:#eef3fa}p{line-height:1.7}"
    document = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>G1 DR 对照实验</title>
<style>{style}</style>
<h1>G1 DR 三组递进实验</h1><p>walk / CR7；每组 seeds 42、43、44；4096 环境；30,000 次更新。
共享摩擦 → 足部摩擦 + 质心/编码器 DR + 六轴推扰 → 增加基座角速度终止。</p>
<p>所有候选使用相同测试条件。先比较完整动作完成率，再比较脚滑、跟踪和关节限位。未完成的动作不会因为误差较小而优先入选。</p>
<h2>每组最佳 checkpoint</h2><table>{table}</table><h2>跨组最佳</h2><ul>{links}</ul>
<h2>最终 iteration 29999：三个 seeds 的 robust 均值 ± 样本标准差</h2>
<table><tr><th>组别</th><th>完成率 %</th><th>跟踪误差 cm</th><th>接触脚滑 m/s</th></tr>{''.join(variance_rows)}</table>
<p>脚滑按承重接触中心的水平速度计算，不包含足底扭转滑动。以上仅为仿真结果，最佳候选不代表全部通过或已通过真机验证。</p>
<p><a href="report.json">完整数据、每个 seed 的全部候选、模型校验和与测试协议</a></p></html>'''
    (args.output / "report.html").write_text(document)
    (args.output / "REPORT_COMPLETE.txt").write_text("18 trainings and 6 three-seed selections complete.\n")
    print(json.dumps(winners), flush=True)


if __name__ == "__main__":
    main()
