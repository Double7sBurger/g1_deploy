"""Re-evaluate one preserved actor on the new common slip protocol."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
b=Path('baselines')/a.label;meta=json.loads((b/'baseline.json').read_text())
checkpoint=b/meta['checkpoint_file'];assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==meta['checkpoint_sha256']
a.output.mkdir(parents=True,exist_ok=True);shutil.copy2(b/'baseline.json',a.output/'baseline.json')
for suite in ('clean','robust'):
 for seed in (2026,2027):
  subprocess.run([sys.executable,'scripts/osmo/evaluate.py','--checkpoint',str(checkpoint),'--motion_file',str(b/'reference.npz'),'--suite',suite,'--seed',str(seed),'--friction_range','0.5','1.5','--output',str(a.output/'evaluations'/suite/str(seed)/'evaluation.json')],check=True)
(a.output/'COMPLETE.txt').write_text(a.label+'\n')
