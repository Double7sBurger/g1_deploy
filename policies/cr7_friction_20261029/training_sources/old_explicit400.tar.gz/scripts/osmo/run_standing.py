"""Train an independent stationary mimic policy and evaluate multiple checkpoints."""

import argparse
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys

import torch
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--iterations', type=int, default=20000)
    parser.add_argument('--num_envs', type=int, default=4096)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.iterations < 2 or args.num_envs < 1:
        parser.error('Need at least two iterations and one environment')
    args.output.mkdir(parents=True, exist_ok=True)
    reference = Path('source/motion_tracking/data/motions/npz/g1_stand_frame0.npz')
    candidates = sorted({args.iterations - 1, *[i for i in (5000, 10000) if i < args.iterations - 1]})
    command = [sys.executable, 'scripts/rsl_rl/train.py', '--task', 'Motion-Standing-G1-v0',
               '--visualizer', 'none', '--num_envs', str(args.num_envs), '--max_iterations', str(args.iterations),
               '--seed', str(args.seed), '--run_name', f'stand_frame0_s{args.seed}',
               'agent.experiment_name=g1_standing', 'agent.save_interval=500']
    experiment = dict(task='Motion-Standing-G1-v0', arm='stand-frame0', seed=args.seed, initialization='random_from_scratch',
                      resume=False, iterations=args.iterations, num_envs=args.num_envs, fixed_frame_index=0,
                      motion_sha256=hashlib.sha256(reference.read_bytes()).hexdigest(), candidates=candidates,
                      evaluation_seeds=[2026, 2027], evaluation_duration_s=60.0,
                      command=command, versions={name: importlib.metadata.version(name) for name in
                          ('newton','warp-lang','mujoco','mujoco-warp','rsl-rl-lib','torch')})
    (args.output/'experiment.json').write_text(json.dumps(experiment, indent=2)+'\n')
    shutil.copy2(reference, args.output/'reference.npz')
    shutil.copy2(reference.with_suffix('.json'), args.output/'reference.json')
    print('STANDING_TRAIN',json.dumps(experiment),flush=True)
    subprocess.run(command, check=True)
    run = sorted(Path('logs/rsl_rl/g1_standing').glob(f'*_stand_frame0_s{args.seed}'))[-1]
    events = EventAccumulator(str(run), size_guidance={'scalars':0}).Reload()
    summary = {}
    for tag in events.Tags()['scalars']:
        values = [p.value for p in events.Scalars(tag)]
        assert values and all(math.isfinite(v) for v in values), tag
        summary[tag] = sum(values[-50:])/len(values[-50:])
    (args.output/'training_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    for iteration in candidates:
        checkpoint=run/f'model_{iteration}.pt'
        state=torch.load(checkpoint,map_location='cpu',weights_only=False)
        def finite(value):
            if isinstance(value,torch.Tensor):return torch.isfinite(value).all().item()
            if isinstance(value,dict):return all(finite(v) for v in value.values())
            if isinstance(value,(tuple,list)):return all(finite(v) for v in value)
            return True
        assert finite(state), checkpoint
        for suite in ('clean','robust'):
            for seed in experiment['evaluation_seeds']:
                target=args.output/'evaluations'/str(iteration)/suite/str(seed)/'evaluation.json'
                subprocess.run([sys.executable,'scripts/osmo/evaluate_standing.py','--checkpoint',str(checkpoint),
                                '--output',str(target),'--suite',suite,'--seed',str(seed)],check=True)
    (args.output/'COMPLETE.txt').write_text(f'stand-frame0 seed={args.seed} iterations={args.iterations}\n')
    print('STANDING_COMPLETE',args.seed,flush=True)


if __name__=='__main__':
    main()
