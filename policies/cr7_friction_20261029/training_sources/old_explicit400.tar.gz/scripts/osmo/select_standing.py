"""Select the best independent standing policy after all three seeds finish."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil


def collect(root):
    experiment=json.loads((root/'experiment.json').read_text())
    assert experiment['initialization']=='random_from_scratch' and not experiment['resume']
    assert experiment['fixed_frame_index']==0 and experiment['task']=='Motion-Standing-G1-v0'
    result=[]
    for iteration in experiment['candidates']:
        checkpoint,=root.rglob(f'model_{iteration}.pt')
        sha=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        suites={}
        for suite in ('clean','robust'):
            reports=[]
            for seed in (2026,2027):
                e=json.loads((root/f'evaluations/{iteration}/{suite}/{seed}/evaluation.json').read_text())
                assert e['protocol']=='static-pose-60s-v1' and e['duration_s']==60 and e['num_envs']==64
                assert e['friction_range']==([1.0,1.0] if suite=='clean' else [0.4,1.2])
                assert e['ground_friction']==0.0
                assert e['checkpoint_sha256']==sha and e['motion_sha256']==experiment['motion_sha256']
                assert e['suite']==suite and e['seed']==seed and len(e['success'])==64
                assert sum(e['success'])/64==e['success_rate']
                if suite=='robust':assert all(not ok or n==11 for ok,n in zip(e['success'],e['push_counts']))
                reports.append(e)
            values={key:sum(e[key] for e in reports)/2 for key in ('success_rate','mean_fraction_survived','joint_limit_violation_fraction')}
            values.update({key:sum(e['mean_errors_while_alive'][key] for e in reports)/2 for key in ('body_pos','joint_rms','joint_speed_rms')})
            values.update(full_trials=128,successful_trials=sum(sum(e['success']) for e in reports),
                          actual_push_count=sum(sum(e['push_counts']) for e in reports),
                          max_xy_drift_m=max(max(e['max_xy_drift_m']) for e in reports),
                          max_orientation_error_deg=max(max(e['max_orientation_error_deg']) for e in reports))
            assert all(math.isfinite(v) for v in values.values())
            suites[suite]=values
        result.append(dict(seed=experiment['seed'],iteration=iteration,checkpoint=str(checkpoint),checkpoint_sha256=sha,
                           motion_sha256=experiment['motion_sha256'],root=str(root),suites=suites))
    return result


def rank(candidate):
    s=list(candidate['suites'].values())
    return (min(v['success_rate'] for v in s),sum(v['success_rate'] for v in s),
            sum(v['mean_fraction_survived'] for v in s),-sum(v['joint_rms'] for v in s),
            -sum(v['body_pos'] for v in s),-sum(v['joint_speed_rms'] for v in s),
            -sum(v['joint_limit_violation_fraction'] for v in s),-candidate['seed'],candidate['iteration'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',type=Path,nargs=3,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    candidates=[]
    for path in args.inputs:
        complete,=path.rglob('COMPLETE.txt')
        candidates.extend(collect(complete.parent))
    assert {v['seed'] for v in candidates}=={42,43,44}
    assert len({v['motion_sha256'] for v in candidates})==1
    candidates.sort(key=rank,reverse=True)
    best=candidates[0]
    args.output.mkdir(parents=True,exist_ok=True)
    selection=dict(task='Motion-Standing-G1-v0',all_three_seeds_complete=True,hardware_validated=False,
                   ranking='worst-suite survival, mean survival, duration survived, joint pose RMS, body position error, joint speed RMS, limit violations',
                   best=best,candidates=candidates,
                   passed_95pct_both_suites=all(v['success_rate']>=.95 for v in best['suites'].values()))
    (args.output/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
    folder=args.output/'best';folder.mkdir(exist_ok=True)
    checkpoint=Path(best['checkpoint']);root=Path(best['root'])
    shutil.copy2(checkpoint,folder/checkpoint.name)
    for name in ('experiment.json','reference.npz','reference.json','source_manifest.json','training_summary.json'):
        shutil.copy2(root/name,folder/name)
    shutil.copytree(checkpoint.parent/'params',folder/'params',dirs_exist_ok=True)
    shutil.copytree(root/'evaluations'/str(best['iteration']),folder/'evaluations',dirs_exist_ok=True)
    assert hashlib.sha256((folder/checkpoint.name).read_bytes()).hexdigest()==best['checkpoint_sha256']
    (args.output/'SELECTION_COMPLETE.txt').write_text(f"seed={best['seed']} iteration={best['iteration']}\n")
    print(json.dumps(selection),flush=True)


if __name__=='__main__':
    main()
