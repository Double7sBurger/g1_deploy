"""Run one fixed-budget reward experiment and verify its saved results."""

import argparse
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
import shutil
import sys

import torch
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--iterations", type=int, required=True)
    parser.add_argument("--num_envs", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--motion_file", type=Path, help="Reference motion override for training and evaluation.")
    parser.add_argument("--action_rate_weight", type=float, help="Use a fixed action penalty instead of a sweep arm.")
    parser.add_argument("--dr", action="store_true", help="Train with height35 DR and evaluate three late checkpoints.")
    parser.add_argument("--friction_range", type=float, nargs=2, metavar=("MIN", "MAX"))
    parser.add_argument("--foot_slip_weight", type=float, default=0.0)
    parser.add_argument("--dr_ablation", choices=("shared", "full", "guard"))
    parser.add_argument("--sysid", action="store_true", help="Use frozen G1 SysID actuators with the baseline no-hands asset.")
    parser.add_argument("--sysid_friction", choices=("shared", "ground"), default="shared")
    args = parser.parse_args()
    if args.sysid:
        assert args.dr and args.friction_range and args.dr_ablation is None
    if args.dr_ablation:
        assert args.dr and args.friction_range and args.foot_slip_weight == 0
    if args.friction_range is not None:
        assert args.dr and 0 < args.friction_range[0] <= args.friction_range[1]
        assert args.foot_slip_weight <= 0
    else:
        assert args.foot_slip_weight == 0
    args.output.mkdir(parents=True, exist_ok=True)
    variants = json.loads(Path(__file__).with_name("reward_sweep.json").read_text())
    weights = variants[args.arm] if args.action_rate_weight is None else {"action_rate_l2": args.action_rate_weight}
    versions = {name: importlib.metadata.version(name) for name in (
        "newton", "mujoco", "mujoco-warp", "warp-lang", "rsl-rl-lib", "torch"
    )}
    ablation_tasks = {"shared": "Shared", "full": "UpstreamDR", "guard": "AngularLimit"}
    command = [
        sys.executable, "scripts/rsl_rl/train.py", "--task",
        (("Motion-Tracking-G1-GroundSysId-v0" if args.sysid_friction == "ground" else "Motion-Tracking-G1-SysId-v0") if args.sysid else
         f"Motion-Tracking-G1-{ablation_tasks[args.dr_ablation]}-v0" if args.dr_ablation else
         "Motion-Tracking-G1-Friction-v0" if args.friction_range else
         "Motion-Tracking-G1-DR-v0" if args.dr else "Motion-Tracking-G1-v0"),
        "--visualizer", "none", "--num_envs", str(args.num_envs),
        "--max_iterations", str(args.iterations), "--seed", str(args.seed),
        "--run_name", f"{args.arm}_s{args.seed}", "agent.save_interval=500",
        *[f"env.rewards.{name}.weight={value}" for name, value in weights.items()],
        *([f"env.commands.motion.motion_file={args.motion_file.resolve()}"] if args.motion_file else []),
    ]
    if args.friction_range:
        command += [
            f"env.events.physics_material.params.static_friction_range={args.friction_range}",
            f"env.events.physics_material.params.dynamic_friction_range={args.friction_range}",
            f"env.rewards.foot_slip.weight={args.foot_slip_weight}",
        ]
    provenance = {"arm": args.arm, "seed": args.seed, "weights": weights, "dr": args.dr,
                  "versions": versions, "command": command}
    if args.friction_range:
        provenance.update(friction_range=args.friction_range, foot_slip_weight=args.foot_slip_weight)
    if args.dr_ablation:
        provenance.update(dr_ablation=args.dr_ablation, evaluation_protocol="shared-dr-v1")
    if args.sysid:
        from motion_tracking.assets.sysid import PARAMETER_FILE, PARAMETER_SHA256
        assert hashlib.sha256(PARAMETER_FILE.read_bytes()).hexdigest() == PARAMETER_SHA256
        shutil.copy2(PARAMETER_FILE, args.output / "sysid_parameters.json")
        provenance.update(sysid_sha256=PARAMETER_SHA256, evaluation_protocol="shared-dr-v1",
                          physics_dt=0.0025, policy_dt=0.02, hands="baseline no Dex3", sysid_friction=args.sysid_friction)
    if args.motion_file:
        provenance["motion_file"] = str(args.motion_file)
        provenance["motion_sha256"] = hashlib.sha256(args.motion_file.read_bytes()).hexdigest()
        if args.dr:
            shutil.copy2(args.motion_file, args.output / "reference.npz")
            shutil.copy2(args.motion_file.with_suffix(".json"), args.output / "reference.json")
    (args.output / "experiment.json").write_text(json.dumps(provenance, indent=2))
    print(json.dumps(provenance), flush=True)
    subprocess.run(command, check=True)
    runs = sorted(Path("logs/rsl_rl/g1_motion_tracking").glob(f"*_{args.arm}_s{args.seed}"))
    run = runs[-1]
    checkpoint = run / f"model_{args.iterations - 1}.pt"
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    tensors = []
    def collect(value):
        if isinstance(value, torch.Tensor):
            tensors.append(value)
        elif isinstance(value, dict):
            for child in value.values():
                collect(child)
        elif isinstance(value, (tuple, list)):
            for child in value:
                collect(child)
    collect(state)
    assert tensors and all(torch.isfinite(t).all() for t in tensors)
    events = EventAccumulator(str(run), size_guidance={"scalars": 0}).Reload()
    summary = {}
    for tag in events.Tags()["scalars"]:
        points = events.Scalars(tag)
        assert all(math.isfinite(point.value) for point in points), tag
        summary[tag] = sum(point.value for point in points[-50:]) / min(50, len(points))
    (args.output / "training_summary.json").write_text(json.dumps(summary, indent=2))
    candidates = sorted({args.iterations - 1, *([20000, 25000] if args.dr and args.iterations >= 30000 else [])})
    for iteration in candidates:
        candidate = run / f"model_{iteration}.pt"
        for suite in (("clean", "robust") if args.dr else ("clean",)):
            for seed in ((2026, 2027) if args.dr else (2026,)):
                output = (args.output / "evaluations" / str(iteration) / suite / str(seed) / "evaluation.json"
                          if args.dr else args.output / "evaluation.json")
                subprocess.run([
                    sys.executable, "scripts/osmo/evaluate.py", "--checkpoint", str(candidate),
                    "--output", str(output), "--suite", suite, "--seed", str(seed),
                    *(["--motion_file", str(args.motion_file)] if args.motion_file else []),
                    *(["--friction_range", *map(str, args.friction_range)] if args.friction_range else []),
                    *(["--protocol", "shared-dr-v1"] if args.dr_ablation or args.sysid else []),
                    *(["--sysid"] if args.sysid else []),
                ], check=True)
    (args.output / "COMPLETE.txt").write_text(f"{args.arm} seed={args.seed} updates={args.iterations}\n")
    print("EXPERIMENT_COMPLETE", args.arm, flush=True)


if __name__ == "__main__":
    main()
