"""Copy one reference pose into a stationary mimic clip with zero velocities."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--frame", type=int, default=0)
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        parser.error("The stationary clip must be separate from the original motion")
    with np.load(args.input) as source:
        if not 0 <= args.frame < len(source["joint_pos"]):
            parser.error("Frame is outside the source motion")
        metadata = json.loads(args.input.with_suffix(".json").read_text())
        result = {"fps": source["fps"]}
        for key in ("joint_names", "body_names"):
            result[key] = source[key] if key in source else np.asarray(metadata[key])
        for key in ("joint_pos", "joint_vel", "body_pos_w", "body_quat_w", "body_lin_vel_w", "body_ang_vel_w"):
            value = np.repeat(source[key][args.frame:args.frame + 1], 2, axis=0)
            if "vel" in key:
                value.fill(0)
            if not np.isfinite(value).all():
                raise ValueError(f"Nonfinite reference field: {key}")
            result[key] = value
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, **result)
    info = dict(source_file=str(args.input), source_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                source_frame=args.frame, kind="static_pose", quaternion_order="wxyz",
                joint_names=result["joint_names"].tolist(), body_names=result["body_names"].tolist(),
                sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(),
                note="Two identical poses, zero velocities; use a fixed-frame command to hold indefinitely.")
    args.output.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info), flush=True)


if __name__ == "__main__":
    main()
