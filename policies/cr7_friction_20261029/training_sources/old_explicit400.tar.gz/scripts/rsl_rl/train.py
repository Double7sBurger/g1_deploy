# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Train the motion task through Isaac Lab's backend-aware RSL-RL entry point."""

import sys
import warp as wp

wp.config.enable_backward = False

from isaaclab_rl.entrypoints import run_train_cli
import motion_tracking.tasks  # noqa: F401


if __name__ == "__main__":
    raise SystemExit(run_train_cli(["--rl_library", "rsl_rl", *sys.argv[1:]]))
