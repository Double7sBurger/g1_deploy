import gymnasium as gym

from . import agents

for suffix, config in (
    ("Shared", "SharedFrictionEnvCfg"),
    ("UpstreamDR", "UpstreamDREnvCfg"),
    ("AngularLimit", "AngularLimitDREnvCfg"),
):
    gym.register(
        id=f"Motion-Tracking-G1-{suffix}-v0",
        entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
        disable_env_checker=True,
        kwargs={
            "env_cfg_entry_point": f"{__name__}.motion_tracking_ablation_env_cfg:{config}",
            "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg",
        },
    )

##
# Register Gym environments.
##

gym.register(
    id="Motion-Tracking-G1-v0",
    entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.motion_tracking_env_cfg:MotionTrackingEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg",
    },
)

gym.register(
    id="Motion-Tracking-G1-DR-v0",
    entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.motion_tracking_dr_env_cfg:MotionTrackingDREnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg",
    },
)

gym.register(
    id="Motion-Standing-G1-v0",
    entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.motion_standing_env_cfg:MotionStandingEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg",
    },
)

gym.register(
    id="Motion-Tracking-G1-Friction-v0",
    entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.motion_tracking_friction_env_cfg:MotionTrackingFrictionEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg",
    },
)

for suffix, config in (("SysId", "MotionTrackingSysIdEnvCfg"), ("GroundSysId", "MotionTrackingGroundSysIdEnvCfg")):
    gym.register(
        id=f"Motion-Tracking-G1-{suffix}-v0",
        entry_point=f"{__name__}.motion_tracking_env:MotionTrackingEnv",
        disable_env_checker=True,
        kwargs={"env_cfg_entry_point": f"{__name__}.motion_tracking_sysid_env_cfg:{config}",
                "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:G1MotionTrackingPPORunnerCfg"},
    )
