"""Paired friction-only and friction-plus-slip experiments."""

from isaaclab.managers import RewardTermCfg
from isaaclab.utils.configclass import configclass
from isaaclab_newton.sensors.contact_sensor import ContactSensorCfg

from .mdp.foot_slip import feet_slip_l2
from .motion_tracking_dr_env_cfg import MotionTrackingDREnvCfg
from .motion_tracking_env_cfg import MotionTrackingSceneCfg, RewardsCfg


@configclass
class FrictionSceneCfg(MotionTrackingSceneCfg):
    foot_ground = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/.*_ankle_roll_link",
        filter_shape_prim_expr=["/World/ground/.*"],
        track_contact_points=True,
        history_length=0,
    )


@configclass
class FrictionRewardsCfg(RewardsCfg):
    foot_slip = RewardTermCfg(
        func=feet_slip_l2, weight=0.0,
        params={"sensor_name": "foot_ground", "force_threshold": 10.0},
    )


@configclass
class MotionTrackingFrictionEnvCfg(MotionTrackingDREnvCfg):
    scene: FrictionSceneCfg = FrictionSceneCfg(num_envs=4096, env_spacing=2.5)
    rewards: FrictionRewardsCfg = FrictionRewardsCfg()

    def __post_init__(self):
        super().__post_init__()
        self.events.physics_material.params["static_friction_range"] = (0.5, 1.5)
        self.events.physics_material.params["dynamic_friction_range"] = (0.5, 1.5)
