"""Newton randomization terms for the shared-friction tracking experiments."""

import torch
import warp as wp
from newton import ModelFlags

from isaaclab.envs.mdp import joint_pos_rel
from isaaclab.envs.mdp.actions.joint_actions import JointPositionAction
from isaaclab.managers import ManagerTermBase
from isaaclab_newton.physics.newton_manager import NewtonManager


class shared_friction(ManagerTermBase):
    """Sample one sliding coefficient per environment for the selected shapes."""

    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        assert "Newton" in env.sim.physics_manager.__name__
        asset_cfg = cfg.params["asset_cfg"]
        asset = env.scene[asset_cfg.name]
        model = NewtonManager.get_model()
        self.friction = wp.to_torch(asset._root_view.get_attribute("shape_material_mu", model)[:, 0])
        self.restitution = wp.to_torch(asset._root_view.get_attribute("shape_material_restitution", model)[:, 0])
        if asset_cfg.body_ids == slice(None):
            indices = list(range(self.friction.shape[1]))
        else:
            indices = []
            for body in asset.map_body_ids_to_backend(asset_cfg.body_ids):
                # USD shape order need not be grouped by body order.
                indices.extend(asset.root_view.link_shapes[body])
        assert indices, "The friction body selection must contain collision shapes."
        self.shape_ids = torch.tensor(indices, device=env.device, dtype=torch.long)
        self.samples = torch.ones(env.num_envs, device=env.device)

    def __call__(self, env, env_ids, static_friction_range, dynamic_friction_range,
                 restitution_range, num_buckets, asset_cfg):
        # Newton has one sliding coefficient; retain the baseline event interface.
        assert tuple(dynamic_friction_range) == tuple(static_friction_range)
        assert tuple(restitution_range) == (0.0, 0.0)
        if env_ids is None:
            env_ids = torch.arange(env.num_envs, device=env.device)
        lo, hi = static_friction_range
        self.samples[env_ids] = torch.empty(len(env_ids), device=env.device).uniform_(lo, hi)
        # Non-selected robot shapes retain the baseline nominal material.
        self.friction[env_ids] = 1.0
        self.restitution[env_ids] = 0.0
        self.friction[env_ids[:, None], self.shape_ids] = self.samples[env_ids, None]
        NewtonManager.add_model_change(ModelFlags.SHAPE_PROPERTIES)


class EncoderBiasJointPositionAction(JointPositionAction):
    """Apply position targets in the same biased encoder coordinates as the actor."""

    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        self.encoder_bias = torch.zeros((env.num_envs, self._asset.num_joints), device=env.device)

    def apply_actions(self):
        target = self.processed_actions - self.encoder_bias[:, self._joint_ids]
        self._asset.set_joint_position_target_index(target=target, joint_ids=self._joint_ids)


def randomize_encoder_bias(env, env_ids, bias_range, action_name="joint_pos"):
    """Set persistent encoder calibration offsets [rad], sampled once at startup."""
    action = env.action_manager.get_term(action_name)
    if env_ids is None:
        env_ids = torch.arange(env.num_envs, device=env.device)
    action.encoder_bias[env_ids] = torch.empty(
        (len(env_ids), action.encoder_bias.shape[1]), device=env.device
    ).uniform_(*bias_range)


def biased_joint_pos_rel(env):
    """Return actor joint positions including persistent encoder bias [rad]."""
    return joint_pos_rel(env) + env.action_manager.get_term("joint_pos").encoder_bias


def base_angular_velocity_limit(env, threshold):
    """Terminate when any root-frame angular velocity component exceeds [rad/s]."""
    return (env.scene["robot"].data.root_ang_vel_b.torch.abs() > threshold).any(dim=-1)
