"""Ground-contact slip measured at each foot's reported contact centroid."""

import torch

from isaaclab.managers import ManagerTermBase


def contact_velocity(com_position, com_velocity, contact_position):
    """Rigid-body point velocity; COM velocity is [linear, angular] in world axes."""
    offset = torch.nan_to_num(contact_position) - com_position
    return com_velocity[..., :3] + torch.cross(com_velocity[..., 3:], offset, dim=-1)


class FootSlipMeasurement:
    """Measure horizontal slip on a stationary plane, excluding airborne feet.

    The Newton sensor reports a contact centroid, not every contact in a patch.
    This measures translation at that centroid; it is not a torsional-slip metric.
    """

    def __init__(self, env, sensor_name="foot_ground", force_threshold=10.0):
        self.sensor = env.scene[sensor_name]
        self.robot = env.scene["robot"]
        self.body_ids = [self.robot.body_names.index(name) for name in self.sensor.sensor_names]
        assert set(self.sensor.sensor_names) == {"left_ankle_roll_link", "right_ankle_roll_link"}
        assert self.sensor.num_filter_objects == 1, "Foot slip requires one stationary ground counterpart."
        self.force_threshold = force_threshold

    def sample(self):
        data = self.sensor.data
        positions = data.contact_pos_w.torch[:, :, 0]
        forces = data.force_matrix_w.torch[:, :, 0]
        contact = (forces[..., 2].abs() > self.force_threshold) & torch.isfinite(positions).all(-1)
        velocity = contact_velocity(
            self.robot.data.body_com_pos_w.torch[:, self.body_ids],
            self.robot.data.body_com_vel_w.torch[:, self.body_ids], positions,
        )
        speed = torch.linalg.vector_norm(velocity[..., :2], dim=-1)
        return torch.where(contact, speed, 0.0), contact


class feet_slip_l2(ManagerTermBase):
    """Sum squared horizontal contact-centroid speeds for loaded feet."""

    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        self.measurement = FootSlipMeasurement(env, **cfg.params)

    def __call__(self, env, sensor_name="foot_ground", force_threshold=10.0):
        speed, _ = self.measurement.sample()
        return speed.square().sum(-1)
