"""Incremental shared-friction, upstream DR, and angular-limit experiments."""

import math

from isaaclab.envs.mdp import randomize_rigid_body_com
from isaaclab.managers import EventTermCfg, SceneEntityCfg, TerminationTermCfg
from isaaclab.utils.configclass import configclass

from .mdp.dr_ablation import (
    EncoderBiasJointPositionAction,
    base_angular_velocity_limit,
    biased_joint_pos_rel,
    randomize_encoder_bias,
    shared_friction,
)
from .motion_tracking_dr_env_cfg import MotionTrackingDREventCfg
from .motion_tracking_friction_env_cfg import MotionTrackingFrictionEnvCfg


@configclass
class SharedFrictionEnvCfg(MotionTrackingFrictionEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.events.physics_material.func = shared_friction


@configclass
class UpstreamDREventCfg(MotionTrackingDREventCfg):
    base_com = EventTermCfg(
        func=randomize_rigid_body_com,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names="torso_link"),
            "com_range": {"x": (-0.025, 0.025), "y": (-0.05, 0.05), "z": (-0.05, 0.05)},
        },
    )
    encoder_bias = EventTermCfg(
        func=randomize_encoder_bias, mode="startup", params={"bias_range": (-0.01, 0.01)}
    )


@configclass
class UpstreamDREnvCfg(SharedFrictionEnvCfg):
    events: UpstreamDREventCfg = UpstreamDREventCfg()

    def __post_init__(self):
        super().__post_init__()
        self.events.physics_material.params["asset_cfg"] = SceneEntityCfg(
            "robot", body_names=["left_ankle_roll_link", "right_ankle_roll_link"]
        )
        self.actions.joint_pos.class_type = EncoderBiasJointPositionAction
        self.observations.policy.joint_pos.func = biased_joint_pos_rel
        self.events.push_robot.interval_range_s = (1.0, 3.0)
        self.events.push_robot.params["velocity_range"] = {
            "x": (-0.5, 0.5), "y": (-0.5, 0.5), "z": (-0.2, 0.2),
            "roll": (-0.52, 0.52), "pitch": (-0.52, 0.52), "yaw": (-0.78, 0.78),
        }


@configclass
class AngularLimitDREnvCfg(UpstreamDREnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.terminations.base_ang_vel_exceed = TerminationTermCfg(
            func=base_angular_velocity_limit, params={"threshold": 500 * math.pi / 180.0}
        )


ABLATION_CONFIGS = {
    "shared": SharedFrictionEnvCfg,
    "full": UpstreamDREnvCfg,
    "guard": AngularLimitDREnvCfg,
}
