"""Mimic a stationary start pose and recover from repeated disturbances."""

from isaaclab.utils.configclass import configclass

from motion_tracking import MOTION_TRACKING_DATA_DIR
from .motion_tracking_dr_env_cfg import MotionTrackingDREnvCfg


@configclass
class MotionStandingEnvCfg(MotionTrackingDREnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.commands.motion.motion_file = f"{MOTION_TRACKING_DATA_DIR}/motions/npz/g1_stand_frame0.npz"
        self.commands.motion.fixed_frame_index = 0
        self.episode_length_s = 20.0
        self.rewards.action_rate_l2.weight = -0.01
        self.events.push_robot.interval_range_s = (3.0, 6.0)
        self.events.push_robot.params["velocity_range"] = {
            "x": (-0.5, 0.5), "y": (-0.5, 0.5),
            "roll": (-0.3, 0.3), "pitch": (-0.3, 0.3), "yaw": (-0.3, 0.3),
        }
