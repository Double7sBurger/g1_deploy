"""Motion tracking with contact friction, mass, push and observation DR."""

from isaaclab.managers import EventTermCfg as EventTerm, SceneEntityCfg
from isaaclab.utils.configclass import configclass
from isaaclab.utils.noise import UniformNoiseCfg

from . import mdp
from .motion_tracking_env_cfg import EventCfg, MotionTrackingEnvCfg


@configclass
class MotionTrackingDREventCfg(EventCfg):
    add_base_mass = EventTerm(
        func=mdp.randomize_rigid_body_mass,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names="torso_link"),
            "mass_distribution_params": (0.8, 1.25),
            "operation": "scale",
            "distribution": "log_uniform",
            "recompute_inertia": True,
        },
    )
    push_robot = EventTerm(
        func=mdp.push_by_setting_velocity,
        mode="interval",
        interval_range_s=(10.0, 15.0),
        # Episodes last at most 10 s; retain the timer so pushes actually occur.
        resample_interval_on_reset=False,
        params={"velocity_range": {"x": (-0.5, 0.5), "y": (-0.5, 0.5)}},
    )


@configclass
class MotionTrackingDREnvCfg(MotionTrackingEnvCfg):
    events: MotionTrackingDREventCfg = MotionTrackingDREventCfg()

    def __post_init__(self):
        super().__post_init__()
        self.events.physics_material.params["static_friction_range"] = (0.4, 1.2)
        self.events.physics_material.params["dynamic_friction_range"] = (0.4, 1.2)
        # MJWarp uses max(ground, robot) for contact friction. A zero ground
        # coefficient lets the randomized robot materials also produce low grip.
        self.scene.terrain.physics_material.static_friction = 0.0
        self.scene.terrain.physics_material.dynamic_friction = 0.0
        self.observations.policy.joint_vel.noise = UniformNoiseCfg(n_min=-1.5, n_max=1.5)
