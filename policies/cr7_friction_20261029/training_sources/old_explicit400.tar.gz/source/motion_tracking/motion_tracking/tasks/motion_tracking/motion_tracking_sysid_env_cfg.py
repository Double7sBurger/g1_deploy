"""Paired shared-material and ground-only DR with the same frozen SysID model."""

from isaaclab.utils.configclass import configclass
from motion_tracking.assets.sysid import apply_sysid
from .mdp.ground_friction import ground_friction
from .motion_tracking_ablation_env_cfg import SharedFrictionEnvCfg


@configclass
class MotionTrackingSysIdEnvCfg(SharedFrictionEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        apply_sysid(self)


@configclass
class MotionTrackingGroundSysIdEnvCfg(MotionTrackingSysIdEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.events.physics_material.func = ground_friction
        self.scene.terrain.physics_material.static_friction = 1.0
        self.scene.terrain.physics_material.dynamic_friction = 1.0
