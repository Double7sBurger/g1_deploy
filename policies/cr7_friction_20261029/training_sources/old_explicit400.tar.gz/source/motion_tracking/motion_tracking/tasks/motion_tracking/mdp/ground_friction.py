"""Per-environment ground friction for Newton's replicated MuJoCo worlds."""

import numpy as np
import torch
import warp as wp
from newton import ModelFlags

from isaaclab.managers import ManagerTermBase
from isaaclab_newton.physics.newton_manager import NewtonManager


class ground_friction(ManagerTermBase):
    """Randomize only the floor; preserve nominal robot and self-contact material."""

    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        self.solver = None
        robot = env.scene[cfg.params["asset_cfg"].name]
        model = NewtonManager.get_model()
        self.friction = wp.to_torch(robot._root_view.get_attribute("shape_material_mu", model)[:, 0])
        self.restitution = wp.to_torch(robot._root_view.get_attribute("shape_material_restitution", model)[:, 0])
        self.samples = torch.ones(env.num_envs, device=env.device)

    def _bind_solver(self):
        self.solver = NewtonManager._solver
        if self.solver.use_mujoco_cpu:
            raise ValueError("Per-world ground DR requires the batched MuJoCo Warp model")
        self.floor_ids = np.flatnonzero(self.solver.mj_model.geom_type == 0).tolist()
        if len(self.floor_ids) != 1:
            raise ValueError(f"Expected one global plane, got {self.floor_ids}")
        original_notify = self.solver.notify_model_changed

        def notify_and_restore_ground(flags):
            original_notify(flags)
            self._apply_ground()

        # Newton stores the global plane once; its replicated solver holds one
        # material per environment. Preserve that override after model updates.
        self.solver.notify_model_changed = notify_and_restore_ground

    def _apply_ground(self):
        material = wp.to_torch(self.solver.mjw_model.geom_friction)
        if material.shape[0] != len(self.samples):
            raise ValueError("The ground coefficient must be independent per environment")
        material[:, self.floor_ids, 0] = self.samples[:, None]
        # A higher floor priority prevents max(robot=1, ground<1) masking DR.
        # Other contact parameters are verified equal before submitting runs.
        priority = wp.to_torch(self.solver.mjw_model.geom_priority)
        priority[self.floor_ids] = 1
        self.solver.mj_model.geom_priority[self.floor_ids] = 1

    def __call__(self, env, env_ids, static_friction_range, dynamic_friction_range,
                 restitution_range, num_buckets, asset_cfg):
        if self.solver is None:
            self._bind_solver()
        assert tuple(static_friction_range) == tuple(dynamic_friction_range)
        assert tuple(restitution_range) == (0.0, 0.0)
        if env_ids is None:
            env_ids = torch.arange(env.num_envs, device=env.device)
        self.friction[env_ids] = 1.0
        self.restitution[env_ids] = 0.0
        self.samples[env_ids] = torch.empty(len(env_ids), device=env.device).uniform_(*static_friction_range)
        NewtonManager.add_model_change(ModelFlags.SHAPE_PROPERTIES)
        self._apply_ground()
