"""Motion environment with contact observations at the physics rate."""

from isaaclab.envs import ManagerBasedRLEnv


class MotionTrackingEnv(ManagerBasedRLEnv):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Newton's fused decimation samples contacts only after the entire control
        # step. The self-collision reward requires all four physics-frame samples.
        self.sim.physics_manager.set_decimation(1)
        self._physics_handles_decimation = False
