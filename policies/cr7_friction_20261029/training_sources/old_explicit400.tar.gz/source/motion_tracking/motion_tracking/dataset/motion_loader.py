# This file includes code derived from HybridRobotics/whole_body_tracking
# (MIT License).
#
# Original source:
# https://github.com/HybridRobotics/whole_body_tracking
#
# Modifications:
#   - Added docstrings.
#   - Added type hints.
#
# See docs/licenses/LICENSE-whole_body_tracking.txt for the full license text.

import numpy as np
import json
import hashlib
import os
import torch
from pathlib import Path
from typing import Sequence


class MotionLoader:
    """Helper class to load and sample motion data from NumPy-file format.

    This class is used to load the motion data from a NumPy file and provide the motion data
    in the world frame. The motion data is stored in the following format:

    - fps: Frames per second.
    - joint_pos: Joint positions. Shape: (time_steps, num_joints).
    - joint_vel: Joint velocities. Shape: (time_steps, num_joints).
    - body_pos_w: Body positions in the world frame. Shape: (time_steps, num_bodies, 3).
    - body_quat_w: WXYZ body quaternions in the world frame. Shape: (time_steps, num_bodies, 4).
    - body_lin_vel_w: Body linear velocities in the world frame. Shape: (time_steps, num_bodies, 3).
    - body_ang_vel_w: Body angular velocities in the world frame. Shape: (time_steps, num_bodies, 3).

    The data is processed from the CSV (BeyondMimic data) or PKL (MimicKit data) to the NumPy file format.
    Please check the `scripts/motions` folder for the conversion scripts.
    Stored WXYZ quaternions are converted to Isaac Lab's XYZW convention when loaded.
    """

    def __init__(
        self, motion_file: str, body_indices: Sequence[int], device: str = "cpu",
        *, body_names: Sequence[str] | None = None, joint_names: Sequence[str] | None = None,
    ):
        """Load a motion file and initialize the internal variables.

        Args:
            motion_file: Motion file path to load.
            body_indices: Indexes of the bodies to load.
            device: The device to which to load the data. Defaults to "cpu".
            body_names: Requested body order, resolved against the file's name metadata.
            joint_names: Runtime joint order, resolved against the file's name metadata.
        """
        # check if the motion file exists
        if not os.path.isfile(motion_file):
            raise FileNotFoundError(f"Motion file not found: {motion_file}")

        # initialize the internal variables
        self._motion_file = motion_file
        self._body_indices = body_indices
        # load the motion file
        data = np.load(self._motion_file)
        joint_indices = slice(None)
        if body_names is not None or joint_names is not None:
            if "body_names" in data and "joint_names" in data:
                names = {key: data[key].tolist() for key in ("body_names", "joint_names")}
            else:
                metadata_path = Path(motion_file).with_suffix(".json")
                if not metadata_path.is_file():
                    raise ValueError(f"Missing body/joint names for {motion_file}; regenerate it with csv_to_npz.py.")
                names = json.loads(metadata_path.read_text())
                if names.get("sha256") != hashlib.sha256(Path(motion_file).read_bytes()).hexdigest():
                    raise ValueError(f"Motion metadata does not match {motion_file}.")
            if body_names is not None:
                self._body_indices = [names["body_names"].index(name) for name in body_names]
            if joint_names is not None:
                joint_indices = [names["joint_names"].index(name) for name in joint_names]
        self.fps = data["fps"]
        self._joint_pos = torch.tensor(data["joint_pos"][:, joint_indices], dtype=torch.float32, device=device)
        self._joint_vel = torch.tensor(data["joint_vel"][:, joint_indices], dtype=torch.float32, device=device)
        self._body_pos_w = torch.tensor(data["body_pos_w"], dtype=torch.float32, device=device)
        self._body_quat_w = torch.tensor(data["body_quat_w"][..., [1, 2, 3, 0]], dtype=torch.float32, device=device)
        self._body_lin_vel_w = torch.tensor(data["body_lin_vel_w"], dtype=torch.float32, device=device)
        self._body_ang_vel_w = torch.tensor(data["body_ang_vel_w"], dtype=torch.float32, device=device)

        # additional properties
        self.time_step_total = self.joint_pos.shape[0]

    def __str__(self):
        msgs = []
        # print the motion file information
        msgs.append(f"Motion file loaded: {self._motion_file}")
        msgs.append(f"  |-- FPS: {self.fps}")
        msgs.append(f"  |-- Time steps: {self.time_step_total}")
        msgs.append(f"  |-- Body indices: {self._body_indices}")
        return "\n".join(msgs)

    """
    Properties.
    """

    @property
    def body_pos_w(self) -> torch.Tensor:
        """Body positions in the world frame. Shape: (time_steps, num_bodies, 3)."""
        return self._body_pos_w[:, self._body_indices]

    @property
    def body_quat_w(self) -> torch.Tensor:
        """Body quaternions in the world frame. Shape: (time_steps, num_bodies, 4).

        The quaternion is in the format of (x, y, z, w).
        """
        return self._body_quat_w[:, self._body_indices]

    @property
    def body_lin_vel_w(self) -> torch.Tensor:
        """Body linear velocities in the world frame. Shape: (time_steps, num_bodies, 3)."""
        return self._body_lin_vel_w[:, self._body_indices]

    @property
    def body_ang_vel_w(self) -> torch.Tensor:
        """Body angular velocities in the world frame. Shape: (time_steps, num_bodies, 3)."""
        return self._body_ang_vel_w[:, self._body_indices]

    @property
    def joint_pos(self) -> torch.Tensor:
        """Joint positions. Shape: (time_steps, num_joints)."""
        return self._joint_pos

    @property
    def joint_vel(self) -> torch.Tensor:
        """Joint velocities. Shape: (time_steps, num_joints)."""
        return self._joint_vel
