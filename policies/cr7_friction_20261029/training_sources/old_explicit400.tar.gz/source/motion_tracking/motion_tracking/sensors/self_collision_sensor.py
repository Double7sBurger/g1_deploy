"""Filtered contact-force history for the Newton motion-tracking task."""

import torch
import warp as wp

from isaaclab_newton.sensors.contact_sensor import ContactSensor
from isaaclab.sensors import ContactSensorCfg
from isaaclab.utils.configclass import configclass


class SelfCollisionSensor(ContactSensor):
    """Keep the largest filtered pair force per physics frame and environment.

    Newton exposes filtered forces but does not populate force_matrix_w_history.
    The reward only needs the maximum magnitude, so storing full pair matrices
    for every history frame would waste memory.
    """

    def _initialize_impl(self):
        super()._initialize_impl()
        if self._data.force_matrix_w is None or self.cfg.history_length < 1:
            raise ValueError("SelfCollisionSensor requires body filters and a positive history_length.")
        self._max_force_history = torch.zeros(
            (self._num_envs, self.cfg.history_length), device=self._device
        )

    @property
    def max_force_history(self) -> torch.Tensor:
        self._update_outdated_buffers()
        return self._max_force_history

    def reset(self, env_ids=None, env_mask=None):
        env_mask = self._resolve_indices_and_mask(env_ids, env_mask)
        super().reset(None, env_mask)
        mask = wp.to_torch(env_mask).bool()
        self._max_force_history.masked_fill_(mask[:, None], 0.0)

    def _update_buffers_impl(self, env_mask):
        super()._update_buffers_impl(env_mask)
        forces = self._data.force_matrix_w.torch
        maximum = torch.linalg.vector_norm(forces, dim=-1).amax(dim=(-1, -2))
        history = self._max_force_history.roll(1, dims=1)
        history[:, 0] = maximum
        mask = wp.to_torch(env_mask).bool()
        self._max_force_history.copy_(torch.where(mask[:, None], history, self._max_force_history))


@configclass
class SelfCollisionSensorCfg(ContactSensorCfg):
    class_type: type = SelfCollisionSensor
