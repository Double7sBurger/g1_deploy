"""Measured G1 actuator parameters and their encoder-coordinate convention."""

import hashlib
import json
from pathlib import Path
import re

import torch

from isaaclab.actuators import DCMotor, DCMotorCfg
from isaaclab.envs.mdp import joint_pos_rel
from isaaclab.utils.configclass import configclass
from motion_tracking import MOTION_TRACKING_DATA_DIR

PARAMETER_FILE = Path(MOTION_TRACKING_DATA_DIR) / "sysid/g1_sysid_20261027.json"
PARAMETER_SHA256 = "fbc6b33b6ae25bdc24de62180ae39963eb3b5801950a4471585185870389deaa"


class SysIdDCMotor(DCMotor):
    """Delay position commands per joint; use current, biased encoder feedback."""

    def __init__(self, cfg, *args, **kwargs):
        super().__init__(cfg, *args, **kwargs)
        self.encoder_bias = self._parse_joint_parameter(cfg.encoder_bias, 0.0)
        self.delay_steps = self._parse_joint_parameter(cfg.delay_steps, 0.0).long()
        if not torch.equal(self.delay_steps, self.delay_steps[:1].expand_as(self.delay_steps)):
            raise ValueError("This fixed SysID model requires identical delays across environments")
        self._length = int(self.delay_steps.max()) + 1
        self._cursor = 0
        self._fresh = torch.ones(self._num_envs, dtype=torch.bool, device=self._device)
        self._history = torch.zeros((self._length, self._num_envs, self.num_joints), device=self._device)
        self._read_indices = (
            torch.arange(self._length, device=self._device)[:, None, None] - self.delay_steps[None]
        ).remainder(self._length)
        # Each joint uses the same torque-speed curve as its individual SysID fit.
        self._saturation_effort = self.effort_limit.clone()
        self._vel_at_effort_lim = 2 * self.velocity_limit

    def reset(self, env_ids):
        super().reset(env_ids)
        self._fresh[env_ids] = True

    def compute(self, control_action, joint_pos, joint_vel):
        target = control_action.joint_positions
        if target is None:
            raise ValueError("SysID replay requires position commands")
        # New episodes have no command history: hold their first command backwards in time.
        torch.where(self._fresh[None, :, None], target[None], self._history, out=self._history)
        self._history[self._cursor].copy_(target)
        indices = self._read_indices[self._cursor].unsqueeze(-1)
        control_action.joint_positions = self._history.permute(1, 2, 0).gather(2, indices).squeeze(-1)
        self._fresh.fill_(False)
        self._cursor = (self._cursor + 1) % self._length
        # Mimic supplies zero velocity targets and feed-forward torque, as in the SysID data.
        return super().compute(control_action, joint_pos - self.encoder_bias, joint_vel)


@configclass
class SysIdDCMotorCfg(DCMotorCfg):
    class_type: type = SysIdDCMotor
    encoder_bias: dict[str, float] | float = 0.0
    delay_steps: dict[str, int] | int = 0


def sysid_joint_pos_rel(env):
    """Expose encoder positions to the actor, while the critic keeps physical positions."""
    robot = env.scene["robot"]
    result = joint_pos_rel(env) - robot.actuators["sysid"].encoder_bias
    action = env.action_manager.get_term("joint_pos")
    if hasattr(action, "encoder_bias"):
        result = result + action.encoder_bias
    return result


def apply_sysid(cfg):
    """Install the frozen 26-joint candidate; waist parameters remain nominal."""
    content = PARAMETER_FILE.read_bytes()
    if hashlib.sha256(content).hexdigest() != PARAMETER_SHA256:
        raise ValueError("Unexpected SysID parameter file")
    parameters = json.loads(content)["joints"]
    names = [f"{name}_joint" for name in parameters]
    names += ["waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint"]
    if len(names) != 29 or len(set(names)) != 29:
        raise ValueError("Expected 26 identified joints and three nominal waist joints")
    nominal = {key: {} for key in ("stiffness", "damping", "armature", "effort_limit_sim", "velocity_limit_sim")}
    for name in names:
        groups = [group for group in cfg.scene.robot.actuators.values()
                  if any(re.fullmatch(expr, name) for expr in group.joint_names_expr)]
        if len(groups) != 1:
            raise ValueError(f"Ambiguous actuator mapping: {name}")
        for key in nominal:
            value = getattr(groups[0], key)
            if isinstance(value, dict):
                matches = [v for expr, v in value.items() if re.fullmatch(expr, name)]
                if len(matches) != 1:
                    raise ValueError(f"Ambiguous {key}: {name}")
                value = matches[0]
            nominal[key][name] = value
    friction, viscous, bias, delay = ({name: 0.0 for name in names} for _ in range(4))
    for short_name, record in parameters.items():
        name = f"{short_name}_joint"
        p = record["parameters"]
        nominal["armature"][name] = p["armature"]
        friction[name] = p["coulomb_friction"]
        viscous[name] = p["viscous_friction"]
        bias[name] = p["encoder_bias"]
        delay[name] = int(p["delay_steps"])
    cfg.scene.robot.actuators = {"sysid": SysIdDCMotorCfg(
        joint_names_expr=names, stiffness=nominal["stiffness"], damping=nominal["damping"],
        armature=nominal["armature"], friction=friction, dynamic_friction=friction, viscous_friction=viscous,
        encoder_bias=bias, delay_steps=delay,
        effort_limit=nominal["effort_limit_sim"], effort_limit_sim=nominal["effort_limit_sim"],
        velocity_limit=nominal["velocity_limit_sim"], velocity_limit_sim=nominal["velocity_limit_sim"],
        saturation_effort=max(nominal["effort_limit_sim"].values()),
    )}
    # Keep the measured 2.5 ms delays exact and the original 50 Hz policy rate.
    cfg.sim.dt = 0.0025
    cfg.decimation = 8
    cfg.sim.render_interval = cfg.decimation
    cfg.observations.policy.joint_pos.func = sysid_joint_pos_rel
    cfg.sysid_sha256 = PARAMETER_SHA256

