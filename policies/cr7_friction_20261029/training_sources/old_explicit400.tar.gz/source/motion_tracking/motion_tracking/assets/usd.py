"""Spawn remote USD assets with their references resolved to the local mirror."""

import os
import posixpath
from pathlib import Path
from urllib.parse import urljoin, urlparse

import isaaclab.sim as sim_utils
from isaaclab.utils.assets import retrieve_file_path
from pxr import Sdf, Usd


def spawn_usd_with_cached_references(
    prim_path: str,
    cfg: sim_utils.UsdFileCfg,
    translation: tuple[float, float, float] | None = None,
    orientation: tuple[float, float, float, float] | None = None,
    **kwargs,
) -> Usd.Prim:
    """Resolve USD references in memory without changing the downloaded source files."""
    if urlparse(cfg.usd_path).scheme not in ("http", "https"):
        return sim_utils.spawn_from_usd(prim_path, cfg, translation, orientation, **kwargs)

    local_root = retrieve_file_path(cfg.usd_path)
    pending = [(cfg.usd_path, local_root)]
    # Keep the edited layers alive until the scene has composed the asset.
    layers = {}
    while pending:
        source_url, local_path = pending.pop()
        if local_path in layers:
            continue
        layer = Sdf.Layer.FindOrOpen(local_path)
        if layer is None:
            raise ValueError(f"Cannot open cached USD layer: {local_path}")
        layers[local_path] = layer
        for reference in layer.GetExternalReferences():
            if Path(reference).suffix.lower() not in (".usd", ".usda", ".usdc"):
                continue
            # A previous spawn in this stage may already have resolved the layer.
            if os.path.isabs(reference):
                continue
            dependency_url = urljoin(source_url, reference)
            source = urlparse(source_url)
            dependency = urlparse(dependency_url)
            relative_path = posixpath.relpath(dependency.path, posixpath.dirname(source.path))
            local_dependency = os.path.normpath(os.path.join(os.path.dirname(local_path), relative_path))
            if dependency.netloc != source.netloc or not Path(local_dependency).is_file():
                local_dependency = retrieve_file_path(dependency_url)
            layer.UpdateExternalReference(reference, local_dependency)
            pending.append((dependency_url, local_dependency))

    return sim_utils.spawn_from_usd(
        prim_path, cfg.replace(usd_path=local_root), translation, orientation, **kwargs
    )
