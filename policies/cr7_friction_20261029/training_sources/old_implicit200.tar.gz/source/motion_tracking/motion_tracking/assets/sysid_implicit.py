"""Five fitted joint parameters with the original Newton implicit PD drives."""

import hashlib
import json
import math
from pathlib import Path
import re

import torch

from isaaclab.envs.mdp import JointPositionAction, joint_pos_rel
from motion_tracking import MOTION_TRACKING_DATA_DIR

PARAMETER_FILE = Path(MOTION_TRACKING_DATA_DIR) / "sysid/g1_sysid_20261027.json"
PARAMETER_SHA256 = "fbc6b33b6ae25bdc24de62180ae39963eb3b5801950a4471585185870389deaa"


def load_parameters():
    content = PARAMETER_FILE.read_bytes()
    if hashlib.sha256(content).hexdigest() != PARAMETER_SHA256:
        raise ValueError("Unexpected SysID parameter file")
    return json.loads(content)


class SysIdImplicitJointPositionAction(JointPositionAction):
    """Delay encoder commands at each physics step, then convert to physical targets."""

    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        source = load_parameters()
        if self._joint_names != self._asset.joint_names:
            raise ValueError("The SysID action must cover every robot joint in articulation order")
        biases, lags = [], []
        for name in self._joint_names:
            p = source["joints"].get(name.removesuffix("_joint"), {}).get("parameters")
            biases.append(p["encoder_bias"] if p else 0.)
            seconds = p["delay_steps"] * source["command_dt_s"] if p else 0.
            # Match the all_five replay: round measured delays up to the 5 ms grid.
            lags.append(math.ceil(seconds / env.physics_dt - 1e-10))
        self.sysid_bias = torch.tensor(biases, device=env.device).expand(env.num_envs, -1).clone()
        self.delay_steps = torch.tensor(lags, device=env.device, dtype=torch.long)
        # Optional additional calibration DR used by the common robust evaluation.
        self.encoder_bias = torch.zeros_like(self.sysid_bias)
        self._length = max(lags) + 1
        self._cursor = 0
        self._fresh = torch.ones(env.num_envs, device=env.device, dtype=torch.bool)
        self._history = torch.zeros((self._length, env.num_envs, self.action_dim), device=env.device)
        self._read_indices = (torch.arange(self._length, device=env.device)[:, None]
                              - self.delay_steps[None]).remainder(self._length)

    def reset(self, env_ids=None):
        super().reset(env_ids)
        self._fresh[env_ids] = True

    def apply_actions(self):
        target = self.processed_actions
        # A new episode starts with its first command held backwards in time.
        torch.where(self._fresh[None, :, None], target[None], self._history, out=self._history)
        self._history[self._cursor].copy_(target)
        indices = self._read_indices[self._cursor][None, :, None].expand(target.shape[0], -1, -1)
        delayed = self._history.permute(1, 2, 0).gather(2, indices).squeeze(-1)
        physical_target = delayed + self.sysid_bias - self.encoder_bias
        self._asset.set_joint_position_target_index(target=physical_target, joint_ids=self._joint_ids)
        self._fresh.fill_(False)
        self._cursor = (self._cursor + 1) % self._length


def sysid_implicit_joint_pos_rel(env):
    action = env.action_manager.get_term("joint_pos")
    return joint_pos_rel(env) - action.sysid_bias + action.encoder_bias


def apply_all_five(cfg):
    """Preserve nominal PD/limits/200 Hz and install all 26 measured joint models."""
    if cfg.sim.dt != .005 or cfg.decimation != 4:
        raise ValueError("all_five uses 200 Hz physics and a 50 Hz policy")
    parameters = load_parameters()["joints"]
    assigned = []
    for actuator in cfg.scene.robot.actuators.values():
        selected = [name + "_joint" for name in parameters
                    if any(re.fullmatch(expr, name + "_joint") for expr in actuator.joint_names_expr)]
        if not selected:
            continue
        for attr, key in (("armature", "armature"), ("friction", "coulomb_friction"),
                          ("dynamic_friction", "coulomb_friction"), ("viscous_friction", "viscous_friction")):
            setattr(actuator, attr, {name: parameters[name.removesuffix("_joint")]["parameters"][key]
                                     for name in selected})
        assigned.extend(selected)
    if len(assigned) != 26 or len(set(assigned)) != 26:
        raise ValueError("Each of the 26 measured joints must belong to exactly one actuator")
    cfg.actions.joint_pos.class_type = SysIdImplicitJointPositionAction
    cfg.observations.policy.joint_pos.func = sysid_implicit_joint_pos_rel
    cfg.sysid_sha256 = PARAMETER_SHA256
