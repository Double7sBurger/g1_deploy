"""Original DR task with all_five implicit drives and fixed floor friction."""

from isaaclab.utils.configclass import configclass
from motion_tracking.assets.sysid_implicit import apply_all_five
from .mdp.ground_friction import ground_friction
from .motion_tracking_friction_env_cfg import MotionTrackingFrictionEnvCfg


@configclass
class MotionTrackingAllFiveEnvCfg(MotionTrackingFrictionEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        apply_all_five(self)
        self.events.physics_material.func = ground_friction
        self.events.physics_material.params["static_friction_range"] = (1., 1.)
        self.events.physics_material.params["dynamic_friction_range"] = (1., 1.)
        self.scene.terrain.physics_material.static_friction = 1.
        self.scene.terrain.physics_material.dynamic_friction = 1.
