"""Evaluate fixed motion rollouts with physics-rate limit checks and pose capture."""

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path

import warp as wp
wp.config.enable_backward = False

import gymnasium as gym
import numpy as np
import torch
from rsl_rl.runners import OnPolicyRunner

from isaaclab.app import launch_simulation
from isaaclab.utils.math import quat_error_magnitude
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper, handle_deprecated_rsl_rl_cfg
from motion_tracking.tasks.motion_tracking.agents.rsl_rl_ppo_cfg import G1MotionTrackingPPORunnerCfg
from motion_tracking.tasks.motion_tracking.motion_tracking_env_cfg import MotionTrackingEnvCfg
from motion_tracking.tasks.motion_tracking.motion_tracking_dr_env_cfg import MotionTrackingDREnvCfg
from motion_tracking.tasks.motion_tracking.motion_tracking_friction_env_cfg import MotionTrackingFrictionEnvCfg
from motion_tracking.tasks.motion_tracking.mdp.foot_slip import FootSlipMeasurement


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--motion_file", type=Path)
    parser.add_argument("--suite", choices=("clean", "robust"), default="clean")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--friction_range", type=float, nargs=2, metavar=("MIN", "MAX"))
    parser.add_argument("--protocol", choices=("fixed-start-v2-fresh-observations", "shared-dr-v1"),
                        default="fixed-start-v2-fresh-observations")
    parser.add_argument("--all_five", action="store_true")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cfg = MotionTrackingDREnvCfg() if args.suite == "robust" else MotionTrackingEnvCfg()
    if args.friction_range:
        assert 0 < args.friction_range[0] <= args.friction_range[1]
        cfg = MotionTrackingFrictionEnvCfg()
        friction = tuple(args.friction_range) if args.suite == "robust" else (1.0, 1.0)
        cfg.events.physics_material.params["static_friction_range"] = friction
        cfg.events.physics_material.params["dynamic_friction_range"] = friction
        if args.suite == "clean":
            cfg.events.add_base_mass = None
            cfg.events.push_robot = None
            cfg.scene.terrain.physics_material.static_friction = 1.0
            cfg.scene.terrain.physics_material.dynamic_friction = 1.0
    if args.suite == "robust":
        # Clips are shorter than the training push interval; test one controlled
        # push at a fixed fraction of each rollout instead of waiting 10–15 s.
        cfg.events.push_robot = None
    if args.protocol == "shared-dr-v1":
        from motion_tracking.tasks.motion_tracking.motion_tracking_ablation_env_cfg import AngularLimitDREnvCfg
        assert args.friction_range
        # Every training arm faces the same test physics, perturbations and failure criteria.
        cfg = AngularLimitDREnvCfg()
        friction = tuple(args.friction_range) if args.suite == "robust" else (1.0, 1.0)
        cfg.events.physics_material.params["static_friction_range"] = friction
        cfg.events.physics_material.params["dynamic_friction_range"] = friction
        cfg.events.push_robot = None
        if args.suite == "clean":
            cfg.events.add_base_mass = None
            cfg.events.base_com = None
            cfg.events.encoder_bias = None
            cfg.scene.terrain.physics_material.static_friction = 1.0
            cfg.scene.terrain.physics_material.dynamic_friction = 1.0
    if args.all_five:
        from motion_tracking.assets.sysid_implicit import apply_all_five, PARAMETER_SHA256
        from motion_tracking.tasks.motion_tracking.mdp.ground_friction import ground_friction
        assert args.protocol == "shared-dr-v1" and args.friction_range == [0.5, 1.5]
        apply_all_five(cfg)
        cfg.events.physics_material.func = ground_friction
        cfg.scene.terrain.physics_material.static_friction = 1.
        cfg.scene.terrain.physics_material.dynamic_friction = 1.
    if args.motion_file:
        cfg.commands.motion.motion_file = str(args.motion_file.resolve())
    cfg.scene.num_envs = 64
    cfg.seed = args.seed
    cfg.observations.policy.enable_corruption = args.suite == "robust"
    agent_cfg = handle_deprecated_rsl_rl_cfg(
        G1MotionTrackingPPORunnerCfg(), importlib.metadata.version("rsl-rl-lib"))
    with launch_simulation(cfg, {"visualizer": None, "visualizer_explicit": True}):
        env = gym.make("Motion-Tracking-G1-v0", cfg=cfg).unwrapped
        assert "Newton" in env.sim.physics_manager.__name__
        assert not env._physics_handles_decimation
        vec_env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)
        runner = OnPolicyRunner(vec_env, agent_cfg.to_dict(), log_dir=None, device=env.device)
        runner.load(str(args.checkpoint))
        policy = runner.get_inference_policy(device=env.device)
        command = env.command_manager.get_term("motion")
        robot = command.robot
        slip = FootSlipMeasurement(env) if args.friction_range else None
        slip_sum = torch.zeros((env.num_envs, 2), device=env.device)
        slip_squared = torch.zeros_like(slip_sum)
        slip_peak = torch.zeros_like(slip_sum)
        slip_count = torch.zeros_like(slip_sum)
        slip_bad = torch.zeros_like(slip_sum)
        slip_trace, contact_trace = [], []
        length = command.motion.time_step_total
        starts = torch.cat([
            torch.zeros(32, device=env.device, dtype=torch.long),
            torch.linspace(0, length - 2, 32, device=env.device).long(),
        ])
        command._adaptive_sampling = lambda ids: command.time_steps.__setitem__(ids, starts[ids])
        env.reset(seed=cfg.seed)
        command._resample_command(torch.arange(env.num_envs, device=env.device))
        env.sim.forward()
        env.scene.update(env.physics_dt)
        command.time_steps -= 1
        command._update_command()
        env.obs_buf = env.observation_manager.compute()
        observations = vec_env.get_observations()
        assert observations["policy"].shape[-1] == 154
        assert observations["critic"].shape[-1] == 286
        horizon = length - 1 - starts
        push_steps = (horizon * (0.25 + 0.25 * (torch.arange(env.num_envs, device=env.device) % 3))).long()
        push_rng = torch.Generator(device=env.device).manual_seed(args.seed + 10000)
        push_delta = torch.rand((env.num_envs, 2), generator=push_rng, device=env.device) - 0.5
        if args.protocol == "shared-dr-v1":
            max_pushes = int(length * env.step_dt) + 2
            push_schedule = torch.ceil((1 + 2 * torch.rand(
                (env.num_envs, max_pushes), generator=push_rng, device=env.device)) / env.step_dt).long().cumsum(-1)
            push_vectors = (2 * torch.rand((env.num_envs, max_pushes, 6), generator=push_rng, device=env.device) - 1) * torch.tensor(
                [0.5, 0.5, 0.2, 0.52, 0.52, 0.78], device=env.device
            )
            push_steps = push_schedule[:, 0].clone()
            push_delta = push_vectors[:, 0].clone()
        pushed = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
        push_counts = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
        push_history = []
        termination_counts = {name: 0 for name in env.termination_manager.active_terms}
        alive = torch.ones(env.num_envs, dtype=torch.bool, device=env.device)
        survived = torch.zeros_like(starts)
        success = torch.zeros_like(alive)
        errors = {name: torch.zeros(env.num_envs, device=env.device) for name in (
            "error_body_pos", "error_body_rot", "error_body_lin_vel", "error_body_ang_vel",
            "error_joint_pos", "error_joint_vel")}
        self_contacts = torch.zeros(env.num_envs, device=env.device)
        foot_names = ["left_ankle_roll_link", "right_ankle_roll_link"]
        foot_ids = [command.cfg.body_names.index(name) for name in foot_names]
        foot_sum = torch.zeros((env.num_envs, 2), device=env.device)
        foot_peak = torch.zeros_like(foot_sum)
        limits = robot.data.joint_pos_limits.torch.clone()
        velocity_limits = robot.data.joint_vel_limits.torch.clone()
        assert torch.isfinite(limits).all() and (velocity_limits > 0).all()
        peak_speed = torch.zeros_like(velocity_limits)
        peak_limit_excess = torch.zeros_like(velocity_limits)
        peak_target_excess = torch.zeros_like(velocity_limits)
        samples = torch.zeros(env.num_envs, device=env.device)
        position_bad = torch.zeros_like(samples)
        velocity_bad = torch.zeros_like(samples)
        trajectory, mesh_positions, mesh_quats, mesh_joints = [], [], [], []
        physics_q, physics_qd, physics_targets = [], [], []
        foot_errors = []

        def excess(position):
            return torch.maximum(limits[..., 0] - position, position - limits[..., 1]).clamp_min(0)

        def record_physics():
            q = robot.data.joint_pos.torch
            qd = robot.data.joint_vel.torch
            target = robot.data.joint_pos_target.torch
            assert torch.isfinite(q).all() and torch.isfinite(qd).all() and torch.isfinite(target).all()
            mask = alive[:, None]
            over = excess(q)
            peak_speed.copy_(torch.maximum(peak_speed, qd.abs() * mask))
            peak_limit_excess.copy_(torch.maximum(peak_limit_excess, over * mask))
            peak_target_excess.copy_(torch.maximum(peak_target_excess, excess(target) * mask))
            samples.add_(alive)
            position_bad.add_((over > np.deg2rad(1)).any(-1) & alive)
            velocity_bad.add_((qd.abs() > velocity_limits * 1.05).any(-1) & alive)
            if slip is not None:
                speed, contact = slip.sample()
                assert torch.isfinite(speed).all()
                speed = speed * alive[:, None]
                contact = contact & alive[:, None]
                slip_sum.add_(speed)
                slip_squared.add_(speed.square())
                slip_peak.copy_(torch.maximum(slip_peak, speed))
                slip_count.add_(contact)
                slip_bad.add_((speed > 0.1) & contact)
                if alive[0]:
                    slip_trace.append(speed[0].cpu().numpy().copy())
                    contact_trace.append(contact[0].cpu().numpy().copy())
            if alive[0]:
                physics_q.append(q[0].cpu().numpy().copy())
                physics_qd.append(qd[0].cpu().numpy().copy())
                physics_targets.append(target[0].cpu().numpy().copy())

        original_update = env.scene.update

        def update_and_record(*args, **kwargs):
            original_update(*args, **kwargs)
            record_physics()

        def record_mesh():
            mesh_positions.append(
                (robot.data.body_pos_w.torch[0] - env.scene.env_origins[0]).cpu().numpy().copy())
            mesh_quats.append(robot.data.body_quat_w.torch[0].cpu().numpy()[:, [3, 0, 1, 2]].copy())
            mesh_joints.append(robot.data.joint_pos.torch[0].cpu().numpy().copy())

        env.scene.update = update_and_record
        with torch.inference_mode():
            record_physics()
            for step in range(length - 1):
                if not alive.any():
                    break
                if args.suite == "robust":
                    ids = (alive & (push_steps == step)).nonzero().flatten()
                    if ids.numel():
                        velocity = robot.data.root_vel_w.torch[ids].clone()
                        velocity[:, :push_delta.shape[1]] += push_delta[ids]
                        robot.write_root_velocity_to_sim_index(root_velocity=velocity, env_ids=ids)
                        env.obs_buf = env.observation_manager.compute()
                        observations = vec_env.get_observations()
                        pushed[ids] = True
                        push_counts[ids] += 1
                        if args.protocol == "shared-dr-v1":
                            push_history.append({"step": step, "env_ids": ids.tolist(),
                                                 "delta": push_delta[ids].tolist()})
                            push_steps[ids] = push_schedule[ids, push_counts[ids]]
                            push_delta[ids] = push_vectors[ids, push_counts[ids]]
                command._update_metrics()
                for name, total in errors.items():
                    values = command.metrics[name]
                    assert torch.isfinite(values).all(), name
                    total.add_(values * alive)
                angles = quat_error_magnitude(
                    command.body_quat_relative_w[:, foot_ids], command.robot_body_quat_w[:, foot_ids])
                foot_sum.add_(angles * alive[:, None])
                foot_peak.copy_(torch.maximum(foot_peak, angles * alive[:, None]))
                self_contacts += (env.scene["self_collision"].max_force_history > 10).sum(-1) * alive
                if alive[0]:
                    record_mesh()
                    trajectory.append(torch.stack([
                        command.robot_body_pos_w[0], command.body_pos_relative_w[0]]).cpu().numpy())
                    foot_errors.append(angles[0].cpu().numpy().copy())
                actions = policy(observations)
                assert torch.isfinite(actions).all()
                observations, _, done, _ = vec_env.step(actions)
                for name in termination_counts:
                    termination_counts[name] += int((env.termination_manager.get_term(name) & alive).sum())
                survived += alive.long()
                reached_end = step + 1 >= horizon
                success |= alive & reached_end & ~done.bool()
                alive &= ~done.bool() & ~reached_end
            if success[0]:
                record_mesh()
        env.scene.update = original_update
        # One initial sample plus one sample for every physics substep while alive.
        torch.testing.assert_close(samples, survived.float() * cfg.decimation + 1)

        def quality(group):
            count = survived[group].sum()
            return {
                "foot_orientation_mean_deg": torch.rad2deg(foot_sum[group].sum(0) / count).tolist(),
                "foot_orientation_peak_deg": torch.rad2deg(foot_peak[group].amax(0)).tolist(),
                "joint_peak_abs_velocity_rad_s": peak_speed[group].amax(0).tolist(),
                "joint_peak_speed_ratio": (peak_speed[group] / velocity_limits[group]).amax(0).tolist(),
                "joint_peak_position_limit_excess_deg": torch.rad2deg(peak_limit_excess[group].amax(0)).tolist(),
                "joint_peak_target_limit_excess_deg": torch.rad2deg(peak_target_excess[group].amax(0)).tolist(),
                "position_violation_physics_frame_fraction_gt_1deg": (position_bad[group].sum() / samples[group].sum()).item(),
                "speed_violation_physics_frame_fraction_gt_105pct": (velocity_bad[group].sum() / samples[group].sum()).item(),
            }

        report = {
            "friction_range": cfg.events.physics_material.params["static_friction_range"],
            "ground_friction": cfg.scene.terrain.physics_material.static_friction,
            "protocol": args.protocol,
            "suite": args.suite,
            "checkpoint": str(args.checkpoint), "seed": cfg.seed,
            "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
            "torso_masses_kg": robot.data.body_mass.torch[:, robot.body_names.index("torso_link")].tolist(),
            "push_steps": push_steps.tolist() if args.suite == "robust" else [],
            "push_delta_xy_m_s": push_delta.tolist() if args.suite == "robust" else [],
            "push_applied": pushed.tolist(),
            "push_counts": push_counts.tolist(),
            "push_history": push_history,
            "termination_counts": termination_counts,
            "motion_file": cfg.commands.motion.motion_file,
            "motion_sha256": hashlib.sha256(Path(cfg.commands.motion.motion_file).read_bytes()).hexdigest(),
            "physics": env.sim.physics_manager.__name__, "control_dt": env.step_dt,
            "full_clip_success_rate": success[:32].float().mean().item(),
            "phase_suffix_success_rate": success[32:].float().mean().item(),
            "full_clip_survival_seconds": (survived[:32].float() * env.step_dt).mean().item(),
            "mean_fraction_survived": (survived / horizon).mean().item(),
            "self_contact_frame_fraction": (self_contacts.sum() / (survived.sum() * cfg.decimation)).item(),
            "start_frames": starts.tolist(), "survived_steps": survived.tolist(), "success": success.tolist(),
            "mean_errors_while_alive": {name: (value.sum() / survived.sum()).item() for name, value in errors.items()},
            "quality_measurement": {
                "physics_sample_dt": env.physics_dt, "foot_orientation_sample_dt": env.step_dt,
                "foot_orientation_alignment": "task XY/yaw-aligned reference",
                "joint_names": robot.joint_names, "foot_names": foot_names,
                "hard_joint_limits_rad": limits[0].tolist(), "configured_velocity_limits_rad_s": velocity_limits[0].tolist(),
                "physics_sample_counts": samples.tolist(),
                "full_clip": quality(slice(0, 32)), "phase_suffix": quality(slice(32, 64)),
            },
        }
        if args.protocol == "shared-dr-v1":
            report["push_schedule_steps"] = push_schedule.tolist() if args.suite == "robust" else []
            report["push_schedule_delta_6d"] = push_vectors.tolist() if args.suite == "robust" else []
            report.pop("push_delta_xy_m_s")
            report.pop("push_steps")
            report["test_settings"] = {
                "shared_friction": True, "friction_bodies": ["left_ankle_roll_link", "right_ankle_roll_link"],
                "angular_limit_deg_s": 500, "push_interval_s": [1, 3] if args.suite == "robust" else None,
                "torso_com_positions_m": robot.data.body_com_pos_b.torch[:, robot.body_names.index("torso_link")].tolist(),
                "encoder_bias_rad": env.action_manager.get_term("joint_pos").encoder_bias.tolist(),
            }
        if args.all_five:
            action = env.action_manager.get_term("joint_pos")
            material = env.event_manager.get_term_cfg("physics_material").func
            report.update(protocol="all-five-ground-v1", all_five=True, sysid_sha256=PARAMETER_SHA256,
                          physics_dt=env.physics_dt, actuator_types={k: type(v).__name__ for k,v in robot.actuators.items()},
                          sysid_bias_rad=action.sysid_bias[0].tolist(), delay_steps=action.delay_steps.tolist(),
                          ground_friction_samples=material.samples.tolist())
            report["test_settings"].update(shared_friction=False, friction_bodies="ground", robot_friction=1.0)
        if slip is not None:
            def slip_quality(group):
                count = slip_count[group].sum(0)
                assert (count > 0).all(), "Each foot must have ground-contact samples."
                return {
                    "mean_speed_m_s": (slip_sum[group].sum() / count.sum()).item(),
                    "rms_speed_m_s": (slip_squared[group].sum() / count.sum()).sqrt().item(),
                    "fraction_gt_0_1_m_s": (slip_bad[group].sum() / count.sum()).item(),
                    "per_foot_mean_speed_m_s": (slip_sum[group].sum(0) / count).tolist(),
                    "per_foot_peak_speed_m_s": slip_peak[group].amax(0).tolist(),
                    "per_trial_distance_m": (slip_sum[group] * env.physics_dt).tolist(),
                    "per_trial_contact_time_s": (slip_count[group] * env.physics_dt).tolist(),
                }
            report["foot_slip"] = {
                "definition": "Horizontal world velocity at the force-weighted contact centroid on stationary ground; normal force >10N; excludes airborne feet; not torsional slip.",
                "physics_sample_dt": env.physics_dt,
                "foot_names": slip.sensor.sensor_names,
                "full_clip": slip_quality(slice(0, 32)),
                "phase_suffix": slip_quality(slice(32, 64)),
            }
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        np.savez_compressed(args.output.with_suffix(".npz"), bodies=np.asarray(trajectory),
                            body_names=command.cfg.body_names, fps=1 / env.step_dt,
                            foot_orientation_errors_rad=np.asarray(foot_errors))
        mesh_path = args.output.with_name("policy_poses.npz")
        np.savez_compressed(mesh_path, fps=1 / env.step_dt, body_pos_w=np.asarray(mesh_positions),
                            body_quat_w=np.asarray(mesh_quats), joint_pos=np.asarray(mesh_joints))
        metadata = {
            "body_names": robot.body_names, "joint_names": robot.joint_names, "quaternion_order": "wxyz",
            "sha256": hashlib.sha256(mesh_path.read_bytes()).hexdigest(), "checkpoint": str(args.checkpoint),
            "seed": cfg.seed, "env_index": 0, "success": bool(success[0]),
            "world_origin_subtracted": env.scene.env_origins[0].cpu().tolist(),
            "provenance": "Actual Newton rollout; first fixed full-clip evaluation trial",
        }
        mesh_path.with_suffix(".json").write_text(json.dumps(metadata, indent=2) + "\n")
        np.savez_compressed(args.output.with_name("physics_diagnostics.npz"),
                            joint_pos=np.asarray(physics_q), joint_vel=np.asarray(physics_qd),
                            joint_target=np.asarray(physics_targets), dt=env.physics_dt,
                            foot_slip_speed_m_s=np.asarray(slip_trace), foot_ground_contact=np.asarray(contact_trace))
        print("EVALUATION", json.dumps(report), flush=True)
        env.close()


if __name__ == "__main__":
    main()
