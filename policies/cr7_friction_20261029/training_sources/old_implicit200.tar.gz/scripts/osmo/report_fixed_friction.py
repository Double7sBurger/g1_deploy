"""Compare nine fixed-friction training groups under one common evaluation."""
import argparse
import hashlib
import html
import json
from pathlib import Path
import shutil
import statistics

def rank(candidate):
    """Completion precedes error: early failure must never look like good tracking."""
    suites = candidate["suites"]
    clean, robust = suites["clean"], suites["robust"]
    return (
        min(clean["full_clip_success_rate"], robust["full_clip_success_rate"]),
        sum(s["full_clip_success_rate"] for s in suites.values()) / 2,
        sum(s["mean_fraction_survived"] for s in suites.values()) / 2,
        sum(s["phase_suffix_success_rate"] for s in suites.values()) / 2,
        -sum(s.get("foot_slip_mean_speed_m_s", 0.0) for s in suites.values()) / 2,
        -sum(s["body_position_error_m"] for s in suites.values()) / 2,
        -sum(s["joint_limit_violation_fraction"] for s in suites.values()) / 2,
        -sum(s["foot_orientation_error_deg"] for s in suites.values()) / 2,
        -candidate["seed"],
        candidate["iteration"],
    )



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, nargs=9, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    groups = []
    for root in args.inputs:
        path, = root.rglob("selection.json")
        selection = json.loads(path.read_text())
        assert selection["all_three_seeds_complete"] and len(selection["candidates"]) == 9
        assert selection["evaluation_protocol"] == "all-five-ground-v1"
        candidates = selection["candidates"]
        mu = selection["best"]["fixed_ground_friction"]
        assert all(c["fixed_ground_friction"] == mu for c in candidates)
        assert {(c["seed"],c["iteration"]) for c in candidates} == {(s,i) for s in (42,43,44) for i in (20000,25000,29999)}
        folder = args.output / "best" / f"mu_{mu:.1f}"
        shutil.copytree(path.parent / "best", folder)
        checkpoint = folder / Path(selection["best"]["checkpoint"]).name
        assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == selection["best"]["checkpoint_sha256"]
        assert hashlib.sha256((folder/"sysid_parameters.json").read_bytes()).hexdigest() == selection["best"]["sysid_sha256"]
        assert hashlib.sha256((folder/"reference.npz").read_bytes()).hexdigest() == selection["best"]["motion_sha256"]
        best_per_seed = [max((c for c in candidates if c["seed"] == seed), key=rank) for seed in (42,43,44)]
        final = [c for c in candidates if c["iteration"] == 29999]
        stats = {}
        for key, choices in (("best_checkpoint_per_seed",best_per_seed),("final_checkpoint",final)):
            stats[key] = {suite: dict(mean=statistics.mean(c["suites"][suite]["full_clip_success_rate"] for c in choices),
                                     std=statistics.pstdev(c["suites"][suite]["full_clip_success_rate"] for c in choices))
                          for suite in ("clean","robust")}
        groups.append(dict(fixed_ground_friction=mu, best=selection["best"], best_per_seed=best_per_seed,
                           statistics=stats, candidates=candidates, packaged_checkpoint=str(checkpoint.relative_to(args.output))))
    groups.sort(key=lambda g:g["fixed_ground_friction"])
    assert [g["fixed_ground_friction"] for g in groups] == [i/10 for i in range(5,14)]
    assert len({g["best"]["sysid_sha256"] for g in groups}) == 1
    assert len({g["best"]["motion_sha256"] for g in groups}) == 1
    winner = max(groups,key=lambda g:rank(g["best"]))
    report = dict(training_runs=27,evaluated_checkpoints=81,protocol="all-five-ground-v1",groups=groups,
                  best_overall=dict(fixed_ground_friction=winner["fixed_ground_friction"],candidate=winner["best"],
                                    packaged_checkpoint=winner["packaged_checkpoint"]),
                  sysid_sha256=winner["best"]["sysid_sha256"],hardware_validated=False,
                  training="CR7; native implicit PD 200Hz, policy 50Hz; all 26 fitted non-waist joints; no Dex3; fixed ground mu0.5..1.3; seeds42/43/44; 30000 updates; original mass/push/observation DR",
                  evaluation="Same test distribution for all 81 candidates: clean floor1.0, robust floorU(0.5,1.5); additional mass/COM/encoder/noise and 1-3s six-axis pushes; 500deg/s guard; 64 full and 64 suffix trials per suite",
                  limitations="Simulation only. Fitted delays rounded up to 5ms as in all_five. Fixed handless asset. Best selection uses these evaluation trials; not an independent hardware guarantee.")
    (args.output/"report.json").write_text(json.dumps(report,indent=2)+"\n")
    rows=[]
    for g in groups:
        b=g["best"];c=b["suites"]["clean"];r=b["suites"]["robust"]
        rows.append(f'<tr><td>{g["fixed_ground_friction"]:.1f}</td><td>{b["seed"]}</td><td>{b["iteration"]}</td>'
                    f'<td>{100*c["full_clip_success_rate"]:.2f}%</td><td>{100*r["full_clip_success_rate"]:.2f}%</td>'
                    f'<td>{100*r["body_position_error_m"]:.2f}</td><td>{r["foot_slip_mean_speed_m_s"]:.4f}</td>'
                    f'<td><a href="{html.escape(g["packaged_checkpoint"])}">checkpoint</a></td></tr>')
    page='<meta charset="utf-8"><title>CR7 all_five fixed friction</title><style>body{font-family:sans-serif;max-width:1200px;margin:36px auto}td,th{padding:10px;border:1px solid #ccc}table{border-collapse:collapse}</style>'
    page+='<h1>CR7 all_five: fixed floor friction</h1>'
    page+=''.join('<p>'+html.escape(report[k])+'</p>' for k in ('training','evaluation','limitations'))
    page+='<table><tr><th>Training mu</th><th>Seed</th><th>Update</th><th>Clean full</th><th>Robust full</th><th>Robust body cm</th><th>Robust slip m/s</th><th>Model</th></tr>'+''.join(rows)+'</table>'
    (args.output/"report.html").write_text(page)
    (args.output/"REPORT_COMPLETE.txt").write_text("27 training runs, 81 evaluated checkpoints, 9 group winners\n")
    print(json.dumps(report),flush=True)


if __name__ == "__main__":
    main()
